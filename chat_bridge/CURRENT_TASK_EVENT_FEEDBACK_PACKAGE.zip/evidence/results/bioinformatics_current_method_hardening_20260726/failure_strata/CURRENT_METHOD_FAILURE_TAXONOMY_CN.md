# Current Method Failure Taxonomy

- Full F5 weakest source by row Accuracy: `oligo0` (0.908744).
- Prefix t=1 Accuracy: 0.947134; Exact: 0.045765; Mean ED: 7.235479.
- Low-anchor, repeated-context, homopolymer, and drift strata are offline diagnostics; none changes online output.
- Fallback strata quantify the frozen conservative policy's fidelity/Exact tradeoff on the balanced diagnostic scope.
- CPL/MUSCLE high-prefix comparisons are copied only from the frozen six-method lock and remain baseline-run aware.
- No order-invariance, universal-dominance, confidence, calibration, or early-stopping claim is made.

High-prefix locked comparison rows extracted: 90.
