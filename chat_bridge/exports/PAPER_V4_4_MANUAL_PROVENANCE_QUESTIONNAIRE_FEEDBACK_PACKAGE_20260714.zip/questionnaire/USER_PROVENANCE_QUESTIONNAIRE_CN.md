# 用户人工 Provenance 确认问卷

本问卷只用于关闭论文数据来源和科研使用依据，不要求用户理解 row key、hash 或内部 pipeline 术语。

## 当前计数

- 上一阶段需要人工确认 scientific-use basis 的实际 condition 数：13
- 本问卷主问题组数：10
- Oligo1-Oligo9 是否合并：yes
- 科学使用依据和再分发状态：已分开询问。

## 通用答案选项

- A. 来自公开论文、公开仓库或公开数据发布。请提供论文/仓库/数据发布页面、下载 ZIP 或 README。
- B. 从师兄、合作者或数据作者处获得。请说明提供者、获得方式和是否允许科研使用。
- C. 项目内部历史数据，获得方式可确认。请提供最早目录、压缩包、交接记录或说明。
- D. 本地脚本生成的 synthetic condition。请提供生成脚本、参数和输入基础数据。
- E. 从某个公开基础数据派生。请提供公开基础数据来源和本地派生脚本/参数。
- F. 记不清来源，但可以提供最早文件、压缩包、目录、README 或聊天/邮件交接记录。
- G. 完全无法确认。

## 每组都请分别回答两件事

1. Scientific-use basis：公开发布；论文附属数据；作者/合作者提供并允许科研使用；项目内部生成；其他；无法确认。
2. Redistribution status：明确允许重新分发；只允许引用/科研使用，不确认再分发；不计划重新分发原始数据；无法确认。

## G01 Oligo1-Oligo9

- Condition ID / display name：`oligo1,oligo2,oligo3,oligo4,oligo5,oligo6,oligo7,oligo8,oligo9`
- Codex 已知本地证据：上一阶段审计未找到 data/bbs_template_clean_ids_production_20260627/oligo1..oligo9 本地目录；已确认不能归入 BBS processed release。
- 已知生成/处理脚本：未发现可闭合的生成脚本；需用户提供原始 bundle、README、脚本或交接说明。
- 当前缺失的唯一关键事实：Oligo1-Oligo9 的整体来源、是否同一 bundle/生成流程、是否共享 reference、科研使用依据。
- 主问题：Oligo1-Oligo9 整体最初来自哪里？它们是九个独立公开数据集，还是同一数据源下的九个处理/噪声条件？是否共享 reference？是否由脚本或参数网格生成？当时是否被授权用于科研实验？是否计划重新分发原始/处理数据？
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：原始 ZIP/目录/README/生成脚本/参数表/交接记录；若为公开数据，请给出公开来源。
- 不回答影响：不回答则不能称为公开数据或 BBS processed release；只能保守写为来源未闭合的本地/处理条件。

## G02 clover / clover_clusters

- Condition ID / display name：`clover,clover_clusters`
- Codex 已知本地证据：上一阶段 CAPPED17_AUTHORITATIVE_LINEAGE.tsv 对这两个条目均为 display_name_only_unresolved，local_payload=none。
- 已知生成/处理脚本：未找到可闭合的 preparation script 或 parent artifact。
- 当前缺失的唯一关键事实：Clover 两个条目的原始来源、二者关系，以及是否有科研使用授权。
- 主问题：Clover 与 clover_clusters 是否来自同一公开/内部数据源？clover_clusters 是 clover 的聚类/处理版本，还是独立条件？请提供最早文件或来源说明。
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：原始 ZIP/目录/README/论文/仓库；若 clover_clusters 由 clover 派生，请给出处理脚本或说明。
- 不回答影响：不回答则这两个条目的 scientific-use basis 保持 critical_manual_review。

## G03 NBT17 variants

- Condition ID / display name：`nbt17_id20_m2m_top500,nbt17_id20_m2m_top5000,nbt17_id20_m2m_top500_k15`
- Codex 已知本地证据：三个 NBT17 variant 在上一阶段表中均为 display_name_only_unresolved；特殊条件表中 nbt17_random_access 只有本地链条，alias 未闭合。
- 已知生成/处理脚本：候选脚本包括 build_final_benchmark.py 和 build_input_audit.py，但无法证明原始公开数据/转换来源。
- 当前缺失的唯一关键事实：NBT17 是否来自 Nature Biotechnology 2017 官方数据、哪个 archive/supplement，以及 top500/top5000/k15 的转换规则。
- 主问题：NBT17 三个 variant 是否都来自同一个 NBT17/random-access 数据源？top500、top5000 和 k15 是如何从原始数据产生的？请提供 archive/README/脚本或说明。
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：原始 archive、论文 supplement、下载脚本、README、top500/top5000/k15 生成脚本或说明。
- 不回答影响：不回答则 NBT17 相关 variant 只能保守保留为本地链条未闭合/人工确认项。

## G04 NComms19 Space Shuttle / Vitruvian variants

- Condition ID / display name：`ncomms19_space_shuttle_k15_min5,ncomms19_space_shuttle_min5,ncomms19_space_shuttle_min5_windowed,ncomms19_vitruvian_min5_windowed`
- Codex 已知本地证据：365 Dishes 已验证 public-to-local continuity；这些 Space Shuttle/Vitruvian variant 仍为 display_name_only_unresolved。
- 已知生成/处理脚本：未找到能把这些 variant 与 uwmisl/data-ncomms19-nanopore 公开文件闭合的审计证据。
- 当前缺失的唯一关键事实：这些 variant 是否也来自 NComms19 公开仓库，具体对应哪个 seqs/read run，以及 windowed/k15/min5 的处理规则。
- 主问题：Space Shuttle/Vitruvian 四个 NComms19 variant 的公开来源和本地处理规则是什么？它们是否来自 uwmisl/data-ncomms19-nanopore 的特定 seqs/read run？
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：公开文件名、原始 FASTQ/FASTA/README、处理脚本、参数说明或最早本地目录。
- 不回答影响：不回答则不能将这些 variant 归到已验证的 365 Dishes continuity。

## G05 trellisbma_datatoprocess_sim

- Condition ID / display name：`trellisbma_datatoprocess_sim`
- Codex 已知本地证据：上一阶段 lineage 为 display_name_only_unresolved，local_payload=none。
- 已知生成/处理脚本：未找到可闭合生成脚本。
- 当前缺失的唯一关键事实：该 sim condition 是 Trellis/BMA 相关公开样例、本地 synthetic，还是他人提供数据。
- 主问题：trellisbma_datatoprocess_sim 的原始来源是什么？如果是本地生成，请提供生成脚本和参数；如果来自外部，请提供来源和科研使用授权。
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：原始目录、生成脚本、Trellis/BMA bundle、README 或交接说明。
- 不回答影响：不回答则 scientific-use basis 保持 critical_manual_review。

## G06 uploaded_* conditions

- Condition ID / display name：`uploaded_compact,uploaded_real_clusters,uploaded_real_clusters_compact`
- Codex 已知本地证据：三个 uploaded 条目均为 display_name_only_unresolved，local_payload=none。
- 已知生成/处理脚本：未找到上传数据来源或 compact/real_clusters 处理规则的闭合证据。
- 当前缺失的唯一关键事实：uploaded 数据的提供者/来源、compact 与 real_clusters 的关系、科研使用依据。
- 主问题：uploaded_compact、uploaded_real_clusters、uploaded_real_clusters_compact 是否来自同一上传数据？上传者/来源是谁？compact 和 real_clusters 是如何处理得到的？
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：上传前原始 ZIP/目录、交接记录、处理脚本、README 或提供者说明。
- 不回答影响：不回答则 uploaded 条目保持 submission-critical provenance blocker。

## G07 DMOS

- Condition ID / display name：`dmos_nanopore`
- Codex 已知本地证据：本地 special audit 只有 build_final_benchmark.py/build_input_audit.py 链条。
- 已知生成/处理脚本：scripts/final_full_17dataset_baseline_benchmark_20260707/build_final_benchmark.py; scripts/final_result_cross_validation_20260711/build_input_audit.py
- 当前缺失的唯一关键事实：公开/内部来源、alias 到 frozen condition 的映射、科研使用依据。
- 主问题：DMOS payload 是否由 prepare_dmos_nanopore.py 或某个 dmos_data_github/JSNNLogo 数据目录生成？原始目录最初是否从公开 GitHub/ZIP 下载，或由他人提供？
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：源仓库/ZIP/README/生成脚本/最早本地目录/提供者说明。
- 不回答影响：不回答则只能保守写为本地链条可见但外部来源未闭合。

## G08 Realtime Readout

- Condition ID / display name：`nanopore_realtime_readout`
- Codex 已知本地证据：本地 special audit 只有 benchmark 构建脚本链条。
- 已知生成/处理脚本：scripts/final_full_17dataset_baseline_benchmark_20260707/build_final_benchmark.py; scripts/final_result_cross_validation_20260711/build_input_audit.py
- 当前缺失的唯一关键事实：公开/内部来源、alias 到 frozen condition 的映射、科研使用依据。
- 主问题：Realtime Readout 的原始 FASTA/FASTQ 或 long-register 数据来自哪个 repo、paper 或本地生成脚本？kmer15/full 转换如何产生？
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：源仓库/ZIP/README/生成脚本/最早本地目录/提供者说明。
- 不回答影响：不回答则只能保守写为本地链条可见但外部来源未闭合。

## G09 RobuSeqNet

- Condition ID / display name：`robuseqnet_test`
- Codex 已知本地证据：本地 special audit 只有 benchmark 构建脚本链条，不能区分模型仓库和数据来源。
- 已知生成/处理脚本：scripts/final_full_17dataset_baseline_benchmark_20260707/build_final_benchmark.py; scripts/final_result_cross_validation_20260711/build_input_audit.py
- 当前缺失的唯一关键事实：公开/内部来源、alias 到 frozen condition 的映射、科研使用依据。
- 主问题：RobuSeqNet test 数据是 external_baselines/RobuSeqNet 仓库自带、另行下载，还是本地生成？请给出数据目录/README/来源说明。
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：源仓库/ZIP/README/生成脚本/最早本地目录/提供者说明。
- 不回答影响：不回答则只能保守写为本地链条可见但外部来源未闭合。

## G10 TreConLM Example

- Condition ID / display name：`treconlm_example`
- Codex 已知本地证据：本地 special audit 只有 benchmark 构建脚本链条。
- 已知生成/处理脚本：scripts/final_full_17dataset_baseline_benchmark_20260707/build_final_benchmark.py; scripts/final_result_cross_validation_20260711/build_input_audit.py
- 当前缺失的唯一关键事实：公开/内部来源、alias 到 frozen condition 的映射、科研使用依据。
- 主问题：TreConLM example 是官方 sample、本地 synthetic，还是从 L110/example 脚本生成？请给出 sample/生成脚本/README。
- 可选择答案：A/B/C/D/E/F/G，必要时补充说明。
- 需要附带：源仓库/ZIP/README/生成脚本/最早本地目录/提供者说明。
- 不回答影响：不回答则只能保守写为本地链条可见但外部来源未闭合。
