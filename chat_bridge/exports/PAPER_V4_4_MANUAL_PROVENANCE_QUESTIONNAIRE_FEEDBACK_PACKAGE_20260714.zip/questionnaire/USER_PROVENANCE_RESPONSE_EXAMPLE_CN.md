# 用户回答格式示例

以下只是格式示例，不代表本项目事实。

```tsv
question_id	condition_or_group	source_type	original_source_name	paper_or_repository	original_archive_or_directory	obtained_from	approximate_date	generation_or_preprocessing_description	scientific_use_basis	permission_or_authorization	redistribution_status	supporting_path_or_attachment	confidence	user_notes
GXX	example_condition	A. 来自公开论文/仓库/数据发布	Example dataset	https://example.org/repo	example.zip	公开下载	2025-01	使用 script.py 生成 prefix payload	公开发布	公开页面允许科研使用	不计划重新分发原始数据	/path/to/example.zip; /path/to/README	high	仅示例
```

如果无法确认来源，请选择 `G. 完全无法确认`，并尽量提供最早能找到的文件、压缩包、README 或交接记录。
