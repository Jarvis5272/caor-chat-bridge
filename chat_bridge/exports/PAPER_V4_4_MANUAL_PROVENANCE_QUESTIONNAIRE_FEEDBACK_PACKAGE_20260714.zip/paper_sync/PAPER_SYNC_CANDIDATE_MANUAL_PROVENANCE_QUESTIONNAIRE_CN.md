# Paper Sync Candidate: Manual Provenance Questionnaire

状态：QUESTIONNAIRE_READY_AUTHOR_RESPONSE_PENDING

Final label：PAPER_V4_4_MANUAL_PROVENANCE_QUESTIONNAIRE_READY

本轮没有运行任何算法实验，没有修改算法、参数、V4.3 源码或锁定数字。

## 需要用户确认

- scientific-use basis 关键 unresolved condition：13
- 主问题组：10
- Oligo1-Oligo9：已合并为一个来源/生成流程问题组
- scientific-use basis 与 redistribution status：已分开

## 关键输出

- `questionnaire/USER_PROVENANCE_QUESTIONNAIRE_CN.md`
- `questionnaire/USER_PROVENANCE_RESPONSE_TEMPLATE.tsv`
- `questionnaire/USER_PROVENANCE_RESPONSE_EXAMPLE_CN.md`
- `manual_review/MANUAL_RESPONSE_CLASSIFICATION_RULES.tsv`
- `manual_review/POST_RESPONSE_PROVENANCE_CLOSURE_PLAN_CN.md`
