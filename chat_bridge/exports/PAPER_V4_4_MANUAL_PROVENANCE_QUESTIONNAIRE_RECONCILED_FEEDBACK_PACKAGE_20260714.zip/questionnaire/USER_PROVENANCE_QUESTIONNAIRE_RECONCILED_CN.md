# 用户 Provenance 问卷范围对齐版

本版只保留 submission-critical 的 13 条权威行对应问题。上一版中的 Oligo1-Oligo9 与 DMOS/Realtime/RobuSeqNet/TreConLM 已改为 context-only / artifact follow-up，不再作为必须立即回答的主 submission 问题。

## 计数

- 权威 critical row 总数：13
- 上一版问卷 alias 总数：26
- context-only alias 数：13
- artifact-only alias 数：13
- 修订后主问题组数：6
- 全部回答充分后：可精确关闭 13/13 critical rows。

## 主问题组

### R01 clover / clover_clusters

- 覆盖 critical rows：`CR01,CR02`
- 覆盖 aliases：`clover,clover_clusters`
- critical row 数：2
- 是否要求同源回答：conditional; user should split if clover_clusters was not derived from clover
- 当前缺失事实：原始来源、二者关系、科研使用依据。
- 主问题：Clover 与 clover_clusters 是否来自同一公开/内部数据源？clover_clusters 是 clover 的聚类/处理版本，还是独立条件？
- 需要附件/路径：原始 ZIP/目录/README/论文/仓库；若派生，请给处理脚本或说明。
- 如果组内不同来源：请在响应模板中拆分成多行，分别填写对应 alias 和证据。

### R02 NBT17 variants

- 覆盖 critical rows：`CR03,CR04,CR05`
- 覆盖 aliases：`nbt17_id20_m2m_top500,nbt17_id20_m2m_top5000,nbt17_id20_m2m_top500_k15`
- critical row 数：3
- 是否要求同源回答：likely same family but must be confirmed
- 当前缺失事实：NBT17 public/source archive、variant 转换规则、科研使用依据。
- 主问题：NBT17 三个 variant 是否都来自同一个 NBT17/random-access 数据源？top500、top5000 和 k15 如何从原始数据产生？
- 需要附件/路径：原始 archive、论文 supplement、下载脚本、README、top500/top5000/k15 生成脚本或说明。
- 如果组内不同来源：请在响应模板中拆分成多行，分别填写对应 alias 和证据。

### R03 NComms19 Space Shuttle variants

- 覆盖 critical rows：`CR06,CR07,CR08`
- 覆盖 aliases：`ncomms19_space_shuttle_k15_min5,ncomms19_space_shuttle_min5,ncomms19_space_shuttle_min5_windowed`
- critical row 数：3
- 是否要求同源回答：conditional; split if k15/min5/windowed do not share a source
- 当前缺失事实：Space Shuttle source file/read run、k15/min5/windowed 处理规则、科研使用依据。
- 主问题：Space Shuttle 三个 variant 的公开来源和本地处理规则是什么？它们是否来自同一 NComms19 source/read run？
- 需要附件/路径：公开文件名、原始 FASTQ/FASTA/README、处理脚本、参数说明或最早本地目录。
- 如果组内不同来源：请在响应模板中拆分成多行，分别填写对应 alias 和证据。

### R04 NComms19 Vitruvian variant

- 覆盖 critical rows：`CR09`
- 覆盖 aliases：`ncomms19_vitruvian_min5_windowed`
- critical row 数：1
- 是否要求同源回答：single critical row
- 当前缺失事实：Vitruvian source file/read run、windowed/min5 处理规则、科研使用依据。
- 主问题：Vitruvian min5 windowed variant 的公开来源和本地处理规则是什么？是否来自 NComms19 public release 的特定 source/read run？
- 需要附件/路径：公开文件名、原始 FASTQ/FASTA/README、处理脚本、参数说明或最早本地目录。
- 如果组内不同来源：请在响应模板中拆分成多行，分别填写对应 alias 和证据。

### R05 trellisbma_datatoprocess_sim

- 覆盖 critical rows：`CR10`
- 覆盖 aliases：`trellisbma_datatoprocess_sim`
- critical row 数：1
- 是否要求同源回答：single critical row
- 当前缺失事实：外部来源或本地 synthetic 生成规则、科研使用依据。
- 主问题：trellisbma_datatoprocess_sim 的原始来源是什么？如果是本地生成，请提供生成脚本和参数；如果来自外部，请提供来源和科研使用授权。
- 需要附件/路径：原始目录、生成脚本、Trellis/BMA bundle、README 或交接说明。
- 如果组内不同来源：请在响应模板中拆分成多行，分别填写对应 alias 和证据。

### R06 uploaded_* conditions

- 覆盖 critical rows：`CR11,CR12,CR13`
- 覆盖 aliases：`uploaded_compact,uploaded_real_clusters,uploaded_real_clusters_compact`
- critical row 数：3
- 是否要求同源回答：conditional; split if uploaded variants came from different submissions
- 当前缺失事实：上传数据来源、compact/real_clusters 关系、科研使用依据。
- 主问题：uploaded_compact、uploaded_real_clusters、uploaded_real_clusters_compact 是否来自同一上传数据？上传者/来源是谁？compact 和 real_clusters 如何处理得到？
- 需要附件/路径：上传前原始 ZIP/目录、交接记录、处理脚本、README 或提供者说明。
- 如果组内不同来源：请在响应模板中拆分成多行，分别填写对应 alias 和证据。

## Context-only / Artifact Follow-up Aliases

以下 alias 不属于 13 条 submission-critical 行；不要因为这些 alias 未回答而阻塞当前 13/13 闭合计数。它们只影响保守措辞、未来 artifact release 或后续补充 provenance。

oligo1, oligo2, oligo3, oligo4, oligo5, oligo6, oligo7, oligo8, oligo9, dmos_nanopore, nanopore_realtime_readout, robuseqnet_test, treconlm_example
