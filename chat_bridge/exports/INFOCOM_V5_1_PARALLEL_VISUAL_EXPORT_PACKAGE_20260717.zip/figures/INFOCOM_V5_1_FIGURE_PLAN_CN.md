# INFOCOM V5.1 Figure Plan

Fig. 1: Two-panel receiver architecture and row reconstruction flow.

- Panel A: receiver-level pipeline from frozen row-key task set Q to worker shards and stable row-key merge.
- Panel B: row-level Anchor-Bounded Reconstruction remains unchanged as F_theta.
- Replaces old method-only schematic if page budget requires consolidation.

Fig. 2: Five-source Accuracy and Mean ED.

- Uses `figure_data/F5_PER_SOURCE_QUALITY_FIGURE_DATA.tsv`.
- Shows per-source trade-offs across Current Method, BBS, VS, BMALA.

Fig. 3: Per-prefix progressive quality.

- Uses `figure_data/F5_PER_PREFIX_FIGURE_DATA.tsv`.
- Shows row-macro Accuracy, Exact, and Mean ED by prefix checkpoint.
- Source-macro per-prefix is not plotted because it is not separately locked.

Fig. 4: Quality-runtime frontier and worker scaling.

- Panel A uses `figure_data/F5_QUALITY_RUNTIME_FRONTIER_DATA.tsv`.
- Panel B uses `figure_data/F5_WORKER_SCALING_FIGURE_DATA.tsv`.
- Caption must say w8/w16 are deployment throughput for the Current Method, not single-core algorithmic speedup over baselines.
