# V5.1 并行接收端执行契约

结论：现有 F5 正式路径足以表述为 **integrated deterministic row-parallel receiver execution**。

边界如下：

- 单行重构语义仍是冻结的 `F_theta`，即 Anchor-Bounded Reconstruction；K=7, W=80, M=2, rho=0.35 均未改变。
- `P in {1,8,16}` 是 maintained runner 的接收端执行策略参数，不是新的重构参数。
- 正式 runner 内部按 immutable prefix-row task set 分发工作，不使用外部 shell sharding 作为正式执行路径。
- 每个 worker 只处理分配到的 row-local bundle，不维护共享 mutable reconstruction state。
- 所有 worker 完成后按 canonical row order / row_key stable merge，恢复与单 worker 相同的输出顺序。
- F5 锁定结果显示 Current Method w1/w8/w16 的输出完全一致，因此允许写 output-invariant row-parallel receiver execution。

允许措辞：

- deterministic row-parallel receiver execution
- integrated receiver-level worker execution
- multi-worker deployment throughput
- stable row-key merge with output invariance

禁止措辞：

- 新算法替代 Anchor-Bounded Reconstruction
- baseline 无法并行
- multi-worker throughput 是 single-core algorithmic speedup
- incremental state reuse、cross-prefix reuse、confidence calibration 或 early stopping
