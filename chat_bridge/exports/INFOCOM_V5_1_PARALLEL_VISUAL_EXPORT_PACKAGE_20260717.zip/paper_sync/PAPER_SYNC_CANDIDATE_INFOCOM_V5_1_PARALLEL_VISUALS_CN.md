# INFOCOM V5.1 Parallel Visuals Paper Sync Candidate

状态：READY_FOR_LOCAL_PAPERLINE_REVIEW

已验证事实：

- F5 正式 Current Method w1/w8/w16 由 maintained runner 参数控制，内部使用 row-level task sharding 和 stable row-key merge。
- 未发现共享 mutable reconstruction state；row-level `F_theta` 未改变。
- w1/w8/w16 输出不变性由 F5 identity/determinism lock 支撑。
- 多 worker 只能表述为 receiver-level deployment throughput；不能与 baseline w1 混写为 single-core algorithmic speedup。

Algorithm 2 插入点：方法章节 Anchor-Bounded Reconstruction 之后，实验设置之前。Algorithm 1 保持单行重构语义，Algorithm 2 描述接收端执行策略。

Abstract/Introduction/Contribution 建议：

- 可新增：the receiver admits deterministic row-parallel execution with stable output invariance.
- 必须限定：parallelism is an execution policy over independent prefix rows; the row-level reconstruction algorithm and parameters are unchanged.
- 禁止：confidence, early stopping, incremental state, cross-prefix reuse, universal dominance, baseline cannot parallelize.

Figure data paths：

- `figure_data/F5_PER_SOURCE_QUALITY_FIGURE_DATA.tsv`
- `figure_data/F5_PER_PREFIX_FIGURE_DATA.tsv`
- `figure_data/F5_QUALITY_RUNTIME_FRONTIER_DATA.tsv`
- `figure_data/F5_WORKER_SCALING_FIGURE_DATA.tsv`
- `figure_data/FIGURE_DATA_SOURCE_AUDIT.tsv`

Page-budget 建议：将 Fig. 1 作为方法图替换旧架构图；Fig. 4 合并 quality-runtime 和 scaling 两个 panel；Illumina/TrellisBMA 仍保持 supplement，不并入 F5 aggregate。

No new experiment: 本同步候选仅使用锁定 F5 artifacts 和 runner code audit。
