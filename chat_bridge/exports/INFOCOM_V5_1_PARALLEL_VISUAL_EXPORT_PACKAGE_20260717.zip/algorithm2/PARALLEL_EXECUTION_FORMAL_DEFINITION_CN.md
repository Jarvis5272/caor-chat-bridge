# Algorithm 2 形式化定义

记 `Q` 为固定、不可变的 prefix-row task set。每个 `q in Q` 已经包含 dataset、cluster、prefix checkpoint、前 t 条 reads 和 row key；reference 不进入 online payload。

`F_theta` 是冻结的单行 Anchor-Bounded Reconstruction，参数为 K=7, W=80, M=2, rho=0.35。V5.1 不改变 `F_theta`。

`G_{theta,P}` 是接收端执行策略：将 `Q` 分配给 `P` 个 worker，分别调用同一 `F_theta`，再按 canonical row order / row key stable merge。本文仅报告已验证的 `P=1,8,16`。

论文边界：

- `P=1` 用于与 BBS/VS/BMALA 的同 benchmark 单 worker 公平比较。
- `P=8,16` 用于部署吞吐量和 worker scaling。
- 不声称 baseline 不能并行；只报告本文 receiver 实现的已测吞吐。
