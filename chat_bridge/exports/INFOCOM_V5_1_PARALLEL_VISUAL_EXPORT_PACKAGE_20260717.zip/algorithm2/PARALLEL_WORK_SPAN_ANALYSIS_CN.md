# Work-span 分析

设 `n=|Q|`，`c(q)` 为 row `q` 的重构成本。行级语义不依赖其他 rows。

- Work: `sum_{q in Q} c(q)`，与 worker 数无关。
- Span: 理想情况下接近 `max_p sum_{q in Q_p} c(q)` 加 stable merge 的 `O(n)` row-key 写出成本。
- 实际 wall-clock 还包含输入读取、bundle 序列化、kernel 子进程启动、输出解析和系统调度开销。

F5 locked worker scaling 只用于经验吞吐报告：

- w1 是公平单 worker 基线。
- w8/w16 是 deployment throughput。
- 不把 w8/w16 对 baseline w1 的比值称作 single-core algorithmic speedup。
