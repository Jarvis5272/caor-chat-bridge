# CAPPED17 Lineage Report

## Status Counts

- `direct_public_continuity_verified`: `1`
- `display_name_only_unresolved`: `13`
- `local_derivation_chain_verified`: `17`
- `processed_release_continuity_verified`: `3`

Actual frozen row-key dataset IDs differ from the V4.3 anonymized condition list; unresolved alias mappings are treated as manual review items.
