# Oligo1-Oligo9 Final Wording

本地审计未发现 `data/bbs_template_clean_ids_production_20260627/oligo1` 至 `oligo9` 目录，且 BBS processed release 证据仅覆盖 Microsoft CNR、Binned Nanopore、Oligo0。因此 Oligo1-Oligo9 不得归属到 BBS release，也不得称为已验证公开数据。除非用户提供匿名别名映射或生成脚本，论文应避免这些名称作为独立来源主张。
