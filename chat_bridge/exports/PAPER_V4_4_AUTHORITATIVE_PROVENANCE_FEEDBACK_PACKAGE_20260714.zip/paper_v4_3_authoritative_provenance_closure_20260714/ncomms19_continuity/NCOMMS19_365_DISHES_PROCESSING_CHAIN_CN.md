# NComms19 365 Dishes Processing Chain

- Public local copy: `/home/hanlinxuan/research/ACOR-online-reconstruction/data/third_generation_nanopore/data-ncomms19-nanopore`.
- Public mapping file states 365-dishes uses `seqs_365-dishes.txt` and sequencing run 16.
- `scripts/prepare_ncomms19_nanopore.py` maps `365-dishes` to `seqs_365-dishes.txt` and `nanopore_run16.fastq.gz`.
- Local full-source neutral format is `data/bbs_template_clean_ids_production_20260627/ncomms19_365_dishes_full_strict_clean/neutral_format`.
- Final continuity status: `direct_public_release_continuity_verified`.
