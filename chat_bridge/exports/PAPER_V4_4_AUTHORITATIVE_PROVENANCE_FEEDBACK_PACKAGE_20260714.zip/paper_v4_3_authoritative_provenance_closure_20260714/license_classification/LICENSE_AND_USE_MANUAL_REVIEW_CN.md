# License and Use Manual Review

- `data_use_basis_requires_manual_confirmation`: `13`
- `local_scientific_use_recorded`: `21`

No legal conclusion is made. Unknown scientific-use basis is separated from artifact redistribution limits.
