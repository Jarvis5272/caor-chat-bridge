# Manual Provenance Questions

- `Q01` `clover`: What is the original source, archive, or generation script for condition `clover`, and how does it map to the frozen row-key condition?
- `Q02` `clover_clusters`: What is the original source, archive, or generation script for condition `clover_clusters`, and how does it map to the frozen row-key condition?
- `Q03` `nbt17_id20_m2m_top500`: What is the original source, archive, or generation script for condition `nbt17_id20_m2m_top500`, and how does it map to the frozen row-key condition?
- `Q04` `nbt17_id20_m2m_top5000`: What is the original source, archive, or generation script for condition `nbt17_id20_m2m_top5000`, and how does it map to the frozen row-key condition?
- `Q05` `nbt17_id20_m2m_top500_k15`: What is the original source, archive, or generation script for condition `nbt17_id20_m2m_top500_k15`, and how does it map to the frozen row-key condition?
- `Q06` `ncomms19_space_shuttle_k15_min5`: What is the original source, archive, or generation script for condition `ncomms19_space_shuttle_k15_min5`, and how does it map to the frozen row-key condition?
- `Q07` `ncomms19_space_shuttle_min5`: What is the original source, archive, or generation script for condition `ncomms19_space_shuttle_min5`, and how does it map to the frozen row-key condition?
- `Q08` `ncomms19_space_shuttle_min5_windowed`: What is the original source, archive, or generation script for condition `ncomms19_space_shuttle_min5_windowed`, and how does it map to the frozen row-key condition?
- `Q09` `ncomms19_vitruvian_min5_windowed`: What is the original source, archive, or generation script for condition `ncomms19_vitruvian_min5_windowed`, and how does it map to the frozen row-key condition?
- `Q10` `trellisbma_datatoprocess_sim`: What is the original source, archive, or generation script for condition `trellisbma_datatoprocess_sim`, and how does it map to the frozen row-key condition?
- `Q11` `uploaded_compact`: What is the original source, archive, or generation script for condition `uploaded_compact`, and how does it map to the frozen row-key condition?
- `Q12` `uploaded_real_clusters`: What is the original source, archive, or generation script for condition `uploaded_real_clusters`, and how does it map to the frozen row-key condition?
- `Q13` `uploaded_real_clusters_compact`: What is the original source, archive, or generation script for condition `uploaded_real_clusters_compact`, and how does it map to the frozen row-key condition?
