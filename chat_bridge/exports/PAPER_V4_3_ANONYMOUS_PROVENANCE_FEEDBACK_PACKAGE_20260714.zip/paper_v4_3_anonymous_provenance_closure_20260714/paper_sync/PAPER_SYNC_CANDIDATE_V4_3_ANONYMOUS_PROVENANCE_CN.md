# V4.3 Anonymous Provenance Closure Sync Candidate

状态：`NOT_READY_FOR_PAPER_SYNC`

原因：

- 权威输入 `paper_inputs/ACOR_INFOCOM_2027_OVERLEAF_V4_2.zip` 缺失。
- 未能验证期望 SHA-256 `f00a99a90d4169d394d48165f8bcb4564c7cab96310adc87829d63c90ba4e9a3`。
- 按协议未审计 V4.0 或其他版本来替代 V4.2。

已确认：

- 算法未修改。
- 默认参数未修改。
- 锁定数字未修改。
- 未运行任何新实验。

下一步：

将正确的 `ACOR_INFOCOM_2027_OVERLEAF_V4_2.zip` 放入 `paper_inputs/` 后重新执行 V4.3 anonymous provenance closure。
