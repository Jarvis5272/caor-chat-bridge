import argparse
import csv

def ed(a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]

def main(argv=None):
    parser = argparse.ArgumentParser(description="Offline evaluator; references never enter online reconstruction.")
    parser.add_argument("--pred", required=True)
    parser.add_argument("--truth", required=True)
    args = parser.parse_args(argv)
    truth = {}
    with open(args.truth, encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            truth[r["row_key"]] = r["reference_sequence"]
    vals = []
    with open(args.pred, encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            ref = truth[r["row_key"]]
            vals.append(1.0 - ed(r["reconstructed_sequence"], ref) / len(ref))
    print(f"rows\t{len(vals)}")
    print(f"accuracy\t{sum(vals)/len(vals):.12f}")
if __name__ == "__main__":
    main()
