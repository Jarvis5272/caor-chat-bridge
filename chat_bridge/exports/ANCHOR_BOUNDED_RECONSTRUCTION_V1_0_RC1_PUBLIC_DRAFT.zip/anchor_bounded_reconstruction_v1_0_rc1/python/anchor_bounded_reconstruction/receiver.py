import argparse
import csv
import json
import subprocess
import sys
import tempfile
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

DEFAULT_CONFIG = {"K": 7, "W": 80, "M": 2, "rho": 0.35}

def read_manifest(path):
    grouped = {}
    order = []
    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f, delimiter="\t")
        required = {"row_key", "dataset_id", "cluster_id", "prefix_t", "read_id", "sequence"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise SystemExit(f"manifest missing required fields: {sorted(missing)}")
        for rec in reader:
            key = rec["row_key"]
            if key not in grouped:
                grouped[key] = {
                    "row_key": key,
                    "dataset_id": rec["dataset_id"],
                    "cluster_id": rec["cluster_id"],
                    "prefix_t": int(rec["prefix_t"]),
                    "reads": [],
                }
                order.append(key)
            grouped[key]["reads"].append((rec["read_id"], rec["sequence"]))
    return [grouped[k] for k in order]

def write_bundle(rows, path):
    with open(path, "w", encoding="utf-8", newline="") as f:
        for row in rows:
            f.write(f"ROW\t{row['row_key']}\t{row['prefix_t']}\t{len(row['reads'])}\n")
            for read_id, sequence in row["reads"]:
                f.write(f"READ\t{read_id}\t{sequence}\n")

def run_shard(args):
    index, rows, kernel, work = args
    shard_dir = Path(work) / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    bundle = shard_dir / f"shard_{index:03d}.bundle.tsv"
    output = shard_dir / f"shard_{index:03d}.output.tsv"
    stderr = shard_dir / f"shard_{index:03d}.stderr.log"
    write_bundle(rows, bundle)
    with open(bundle, "r", encoding="utf-8") as stdin, open(output, "w", encoding="utf-8") as stdout, open(stderr, "w", encoding="utf-8") as err:
        proc = subprocess.run([str(kernel)], stdin=stdin, stdout=stdout, stderr=err)
    return {"index": index, "exit_code": proc.returncode, "output": str(output), "stderr": str(stderr)}

def load_kernel_outputs(shard_outputs):
    by_key = {}
    for path in sorted(shard_outputs):
        with open(path, encoding="utf-8", newline="") as f:
            for rec in csv.DictReader(f, delimiter="\t"):
                by_key[rec["row_key"]] = rec
    return by_key

def reconstruct(manifest, output, kernel, workers):
    rows = read_manifest(manifest)
    if workers < 1:
        raise SystemExit("--workers must be >= 1")
    with tempfile.TemporaryDirectory(prefix="abr_receiver_") as tmp:
        groups = [[] for _ in range(workers)]
        for i, row in enumerate(rows):
            groups[i % workers].append(row)
        jobs = [(i, groups[i], kernel, tmp) for i in range(workers)]
        results = []
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(run_shard, job) for job in jobs]
            for future in as_completed(futures):
                results.append(future.result())
        if any(r["exit_code"] != 0 for r in results):
            raise SystemExit("kernel shard failed; see stderr in temporary worker logs")
        by_key = load_kernel_outputs([r["output"] for r in results])
        seen = set()
        out_rows = []
        for row in rows:
            rec = by_key.get(row["row_key"])
            seq = rec.get("output_sequence", "") if rec else ""
            out_rows.append({
                "row_key": row["row_key"],
                "dataset_id": row["dataset_id"],
                "cluster_id": row["cluster_id"],
                "prefix_t": row["prefix_t"],
                "reconstructed_sequence": seq,
                "status": "completed" if seq else "empty",
            })
            seen.add(row["row_key"])
        if len(seen) != len(rows) or set(by_key) != seen:
            raise SystemExit("missing or duplicate row_key in kernel outputs")
    with open(output, "w", encoding="utf-8", newline="") as f:
        fields = ["row_key", "dataset_id", "cluster_id", "prefix_t", "reconstructed_sequence", "status"]
        writer = csv.DictWriter(f, delimiter="\t", fieldnames=fields)
        writer.writeheader()
        writer.writerows(out_rows)

def main(argv=None):
    parser = argparse.ArgumentParser(description="Anchor-Bounded Reconstruction receiver. P is an execution parameter; row-level reconstruction is unchanged.")
    parser.add_argument("--manifest", required=True, help="TSV with row_key,dataset_id,cluster_id,prefix_t,read_id,sequence")
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=1, help="receiver worker budget; tested examples use 1 and 4")
    parser.add_argument("--config", default="configs/default.yaml", help="documented defaults: K=7,W=80,M=2,rho=0.35")
    parser.add_argument("--kernel", default="build/abr-kernel")
    args = parser.parse_args(argv)
    reconstruct(Path(args.manifest), Path(args.output), Path(args.kernel), args.workers)

if __name__ == "__main__":
    main()
