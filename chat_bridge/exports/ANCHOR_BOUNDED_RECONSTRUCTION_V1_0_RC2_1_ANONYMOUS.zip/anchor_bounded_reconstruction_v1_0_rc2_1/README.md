# Anchor-Bounded Reconstruction 1.0.0-rc2.1

This release candidate contains the frozen row-level Anchor-Bounded Reconstruction receiver and deterministic row-parallel execution wrapper used for the INFOCOM paper line.

## Scope

The online reconstruction process reads only visible prefix reads. Reference sequences are stored in a separate offline truth manifest and are used only by `abr-evaluate` or `abr-reproduce` after reconstruction completes.

## Build

```bash
cmake -S . -B build
cmake --build build
export PYTHONPATH="$PWD/python"
```

A direct compiler build is also valid:

```bash
mkdir -p build
g++ -std=c++17 -O2 -Iinclude src/abr_kernel.cpp -o build/abr-kernel
```

## Tiny Example

```bash
python -m anchor_bounded_reconstruction.receiver --manifest examples/tiny_manifest.tsv --output example_output.tsv --workers 1 --kernel build/abr-kernel
python -m anchor_bounded_reconstruction.receiver --manifest examples/tiny_manifest.tsv --output example_output_w4.tsv --workers 4 --kernel build/abr-kernel
python -m anchor_bounded_reconstruction.evaluate --pred example_output.tsv --truth examples/tiny_truth.tsv
```

## Prepare Paper Data

`abr-data prepare` supports: `neutral_manifest_v1`, `oligo0_v1`, `ncomms19_365dishes_v1`, `binned_nanopore_v1`, `microsoft_cnr_processed_v1`, `dnaformer_binned_v1`, and `trellisbma_datatoprocess_v1`.

```bash
python -m anchor_bounded_reconstruction.reproduce --recipe recipes/f5.yaml --data-root /path/to/paper-data --work-dir runs/f5 --workers 16 --kernel build/abr-kernel
python -m anchor_bounded_reconstruction.reproduce --recipe recipes/illumina.yaml --data-root /path/to/paper-data --work-dir runs/illumina --workers 16 --kernel build/abr-kernel
```

Paper datasets are not bundled. Recipes list the required relative input paths, SHA-256 checks, expected scopes, and row-key hashes. Runtime is hardware dependent and is not a paper result.

## License

Code license is pending an author decision. Do not publish this draft as a public GitHub release until the license and double-blind identity fields are manually resolved.
