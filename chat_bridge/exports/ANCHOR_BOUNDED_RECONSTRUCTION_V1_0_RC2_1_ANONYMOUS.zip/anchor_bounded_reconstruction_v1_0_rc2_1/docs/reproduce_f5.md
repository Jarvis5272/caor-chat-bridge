Use `python -m anchor_bounded_reconstruction.reproduce --recipe recipes/f5.yaml --data-root /path/to/paper-data --work-dir runs/f5 --workers 16 --kernel build/abr-kernel`.
