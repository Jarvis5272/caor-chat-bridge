Use `python -m anchor_bounded_reconstruction.reproduce --recipe recipes/illumina.yaml --data-root /path/to/paper-data --work-dir runs/illumina --workers 16 --kernel build/abr-kernel`.
