Paper data are not bundled. Obtain the DNAformer binned files from Zenodo DOI 10.5281/zenodo.13896773 and place all required files under the data root at the recipe-relative paths.
