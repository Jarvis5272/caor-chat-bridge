Clean-room qualification should set PYTHONPATH only to the extracted package `python/` directory and build `build/abr-kernel` from source.
