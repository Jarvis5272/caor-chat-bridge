Hash mismatches, malformed clusters, duplicate row keys, and missing rows are hard errors. Delete the work directory to rebuild all derived caches from source data.
