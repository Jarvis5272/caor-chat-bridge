Online manifests contain row_key, dataset_id, cluster_id, prefix_t, and visible reads only. Offline truth is separate and contains row_key and reference_sequence.
