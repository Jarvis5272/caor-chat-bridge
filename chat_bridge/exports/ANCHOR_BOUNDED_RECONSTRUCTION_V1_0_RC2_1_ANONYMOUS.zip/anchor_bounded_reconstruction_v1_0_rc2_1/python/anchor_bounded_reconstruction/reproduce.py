
from __future__ import annotations
import argparse, csv, json, shutil, subprocess, sys
from pathlib import Path
from .data import sha256_file, write_tsv

VERSION = "1.0.0-rc2.1"

def load_recipe(path):
    text = Path(path).read_text(encoding="utf-8")
    return json.loads(text)

def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def concat_files(paths, dest, skip_header=False):
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("w", encoding="utf-8") as out:
        first = True
        for path in paths:
            with Path(path).open(encoding="utf-8") as f:
                for i, line in enumerate(f):
                    if skip_header and i == 0 and not first:
                        continue
                    out.write(line)
            first = False

def rewrite_row_ids(row_key_paths, dest):
    fields = ["row_id","dataset_id","cluster_id","prefix_t","available_reads","used_reads","row_key","source_cluster_record","source_read_range"]
    rows = []
    for path in row_key_paths:
        rows.extend(read_tsv(path))
    for i, row in enumerate(rows):
        row["row_id"] = i
    write_tsv(dest, rows, fields)
    return rows

def compare_float(obs, exp, tol=1e-9):
    return abs(float(obs) - float(exp)) <= tol

def main(argv=None):
    p = argparse.ArgumentParser(description="One-command paper-data reproduction from source files.")
    p.add_argument("--version", action="version", version=VERSION)
    p.add_argument("--recipe", required=True)
    p.add_argument("--data-root", required=True)
    p.add_argument("--work-dir", required=True)
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--kernel", default="build/abr-kernel")
    args = p.parse_args(argv)
    recipe = load_recipe(args.recipe)
    data_root = Path(args.data_root)
    work = Path(args.work_dir); work.mkdir(parents=True, exist_ok=True)
    prepared = work / "prepared"; combined = work / "combined"; combined.mkdir(parents=True, exist_ok=True)
    trace = []
    row_key_paths = []
    payload_paths = []
    truth_paths = []
    source_dep_rows = []
    scope_rows = []
    for idx, source in enumerate(recipe["sources"]):
        src_path = data_root / source["input_path"]
        actual_sha = sha256_file(src_path) if src_path.is_file() else ""
        exp_sha = source.get("expected_sha256", "")
        status = "pass" if (not exp_sha or actual_sha == exp_sha) else "fail"
        source_dep_rows.append({"source_id": source["source_id"], "path": str(src_path), "expected_sha256": exp_sha, "actual_sha256": actual_sha, "status": status})
        if status != "pass":
            raise SystemExit(f"source hash mismatch: {source['source_id']}")
        out_dir = prepared / f"{idx:02d}_{source['source_id']}"
        cmd = [sys.executable, "-m", "anchor_bounded_reconstruction.data", "prepare", "--adapter", source["adapter"], "--input", str(src_path), "--dataset-id", source["dataset_id"], "--checkpoints", ",".join(map(str, source["checkpoints"])), "--output", str(out_dir)]
        if exp_sha:
            cmd.extend(["--expected-sha256", exp_sha])
        subprocess.check_call(cmd)
        summary = read_tsv(out_dir / "scope_summary.tsv")[0]
        for key in ("clusters","reads","prefix_rows","prefix_read_uses"):
            if int(summary[key]) != int(source[f"expected_{key}"]):
                raise SystemExit(f"scope mismatch for {source['source_id']}: {key} {summary[key]} != {source[f'expected_{key}']}")
        scope_rows.append({"source_id": source["source_id"], **summary})
        row_key_paths.append(out_dir / "row_keys.tsv")
        payload_paths.append(out_dir / "payload_cache.jsonl")
        truth_paths.append(out_dir / "offline_truth.tsv")
        trace.append({"step": "prepare", "source_id": source["source_id"], "status": "pass", "output": str(out_dir)})
    combined_row_keys = combined / "row_keys.tsv"
    rows = rewrite_row_ids(row_key_paths, combined_row_keys)
    if sha256_file(combined_row_keys) != recipe["expected_combined_row_key_sha256"]:
        raise SystemExit(f"combined row-key hash mismatch: {sha256_file(combined_row_keys)}")
    payload = combined / "payload_cache.jsonl"
    concat_files(payload_paths, payload)
    truth = combined / "offline_truth.tsv"
    concat_files(truth_paths, truth, skip_header=True)
    if len(rows) != int(recipe["expected_scope"]["prefix_rows"]):
        raise SystemExit("combined row count mismatch")
    recon = work / "reconstruction.tsv"
    subprocess.check_call([sys.executable, "-m", "anchor_bounded_reconstruction.receiver", "--payload-cache-jsonl", str(payload), "--output", str(recon), "--workers", str(args.workers), "--kernel", args.kernel])
    trace.append({"step": "reconstruct", "source_id": "combined", "status": "pass", "output": str(recon)})
    metrics = work / "metrics.tsv"
    subprocess.check_call([sys.executable, "-m", "anchor_bounded_reconstruction.evaluate", "--pred", str(recon), "--truth-jsonl-cache", str(payload), "--output", str(metrics)])
    metric = read_tsv(metrics)[0]
    lock = recipe.get("number_lock", {})
    metric_rows = []
    for obs_key, exp_key in [("accuracy","accuracy"),("exact","exact"),("mean_edit_distance","mean_edit_distance"),("source_macro_accuracy","source_macro_accuracy")]:
        if exp_key in lock and lock[exp_key] != "":
            ok = compare_float(metric[obs_key], lock[exp_key])
            metric_rows.append({"metric": obs_key, "observed": metric[obs_key], "expected": lock[exp_key], "status": "pass" if ok else "fail"})
            if not ok:
                raise SystemExit(f"number lock metric mismatch: {obs_key}")
    write_tsv(work / "reproduce_trace.tsv", trace, ["step","source_id","status","output"])
    write_tsv(work / "input_dependency_audit.tsv", source_dep_rows, ["source_id","path","expected_sha256","actual_sha256","status"])
    write_tsv(work / "scope_summary.tsv", scope_rows)
    write_tsv(work / "intermediate_cache_audit.tsv", [
        {"artifact": "combined_payload_cache", "path": str(payload), "derived_in_work_dir": "yes", "hidden_input": "no", "sha256": sha256_file(payload)},
        {"artifact": "combined_row_keys", "path": str(combined_row_keys), "derived_in_work_dir": "yes", "hidden_input": "no", "sha256": sha256_file(combined_row_keys)},
    ])
    write_tsv(work / "number_lock_comparison.tsv", metric_rows, ["metric","observed","expected","status"])
    print(f"output={recon}")
    print(f"metrics={metrics}")

if __name__ == "__main__":
    main()
