import argparse
import csv
import json
import subprocess
import tempfile
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

VERSION = "1.0.0-rc2.1"

def read_manifest(path):
    grouped = {}
    order = []
    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f, delimiter="\t")
        required = {"row_key", "dataset_id", "cluster_id", "prefix_t", "read_id", "sequence"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise SystemExit(f"manifest missing required fields: {sorted(missing)}")
        for rec in reader:
            key = rec["row_key"]
            if key not in grouped:
                grouped[key] = {"row_key": key, "dataset_id": rec["dataset_id"], "cluster_id": rec["cluster_id"], "prefix_t": int(rec["prefix_t"]), "reads": []}
                order.append(key)
            grouped[key]["reads"].append((rec["read_id"], rec["sequence"]))
    return [grouped[k] for k in order]

def read_payload_cache_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            obj = json.loads(line)
            # Deliberately ignore reference/target fields. Online reconstruction
            # uses only row key, prefix_t, and visible reads.
            rows.append({
                "row_key": obj["row_key"],
                "dataset_id": obj["dataset_id"],
                "cluster_id": obj["cluster_id"],
                "prefix_t": int(obj["prefix_t"]),
                "reads": [(r["read_id"], r["sequence"]) for r in obj["reads"]],
            })
    return rows

def write_bundle(rows, path):
    with open(path, "w", encoding="utf-8", newline="") as f:
        for row in rows:
            f.write(f"ROW\t{row['row_key']}\t{row['prefix_t']}\t{len(row['reads'])}\n")
            for read_id, sequence in row["reads"]:
                f.write(f"READ\t{read_id}\t{sequence}\n")

def run_shard(args):
    index, rows, kernel, work = args
    shard_dir = Path(work) / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    bundle = shard_dir / f"shard_{index:03d}.bundle.tsv"
    output = shard_dir / f"shard_{index:03d}.output.tsv"
    stderr = shard_dir / f"shard_{index:03d}.stderr.log"
    write_bundle(rows, bundle)
    with open(bundle, "r", encoding="utf-8") as stdin, open(output, "w", encoding="utf-8") as stdout, open(stderr, "w", encoding="utf-8") as err:
        proc = subprocess.run([str(kernel)], stdin=stdin, stdout=stdout, stderr=err)
    return {"index": index, "exit_code": proc.returncode, "output": str(output)}

def load_kernel_outputs(shard_outputs):
    by_key = {}
    for path in sorted(shard_outputs):
        with open(path, encoding="utf-8", newline="") as f:
            for rec in csv.DictReader(f, delimiter="\t"):
                by_key[rec["row_key"]] = rec
    return by_key

def reconstruct(rows, output, kernel, workers):
    if workers < 1:
        raise SystemExit("--workers must be >= 1")
    with tempfile.TemporaryDirectory(prefix="abr_receiver_") as tmp:
        groups = [[] for _ in range(workers)]
        for i, row in enumerate(rows):
            groups[i % workers].append(row)
        jobs = [(i, groups[i], kernel, tmp) for i in range(workers)]
        results = []
        with ProcessPoolExecutor(max_workers=workers) as pool:
            for future in as_completed([pool.submit(run_shard, job) for job in jobs]):
                results.append(future.result())
        if any(r["exit_code"] != 0 for r in results):
            raise SystemExit("kernel shard failed")
        by_key = load_kernel_outputs([r["output"] for r in results])
        seen = set()
        out_rows = []
        for row in rows:
            rec = by_key.get(row["row_key"])
            seq = rec.get("output_sequence", "") if rec else ""
            out_rows.append({"row_key": row["row_key"], "dataset_id": row["dataset_id"], "cluster_id": row["cluster_id"], "prefix_t": row["prefix_t"], "reconstructed_sequence": seq, "status": "completed" if seq else "empty"})
            seen.add(row["row_key"])
        if len(seen) != len(rows) or set(by_key) != seen:
            raise SystemExit("missing or duplicate row_key in kernel outputs")
    with open(output, "w", encoding="utf-8", newline="") as f:
        fields = ["row_key", "dataset_id", "cluster_id", "prefix_t", "reconstructed_sequence", "status"]
        writer = csv.DictWriter(f, delimiter="\t", fieldnames=fields)
        writer.writeheader()
        writer.writerows(out_rows)

def main(argv=None):
    parser = argparse.ArgumentParser(description="Anchor-Bounded Reconstruction receiver. --workers is a deterministic execution parameter.")
    parser.add_argument("--version", action="version", version=VERSION)
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--manifest", help="abr-online-manifest-v1 TSV")
    src.add_argument("--payload-cache-jsonl", help="release-local JSONL payload cache; reference fields are ignored by reconstruction")
    parser.add_argument("--output")
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--kernel", default="build/abr-kernel")
    args = parser.parse_args(argv)
    rows = read_payload_cache_jsonl(args.payload_cache_jsonl) if args.payload_cache_jsonl else read_manifest(args.manifest)
    reconstruct(rows, Path(args.output), Path(args.kernel), args.workers)

if __name__ == "__main__":
    main()
