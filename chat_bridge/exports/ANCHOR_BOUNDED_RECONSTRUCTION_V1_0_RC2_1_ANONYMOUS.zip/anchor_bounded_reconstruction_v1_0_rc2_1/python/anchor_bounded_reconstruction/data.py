
from __future__ import annotations
import argparse, csv, hashlib, json
from pathlib import Path

PREFIXES_DEFAULT = (1, 2, 3, 5, 10, 20)
VERSION = "1.0.0-rc2.1"

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def write_tsv(path, rows, fields=None):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fields = fields or (list(rows[0]) if rows else [])
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, delimiter="\t", fieldnames=fields, extrasaction="ignore", lineterminator="\n")
        w.writeheader(); w.writerows([{k: r.get(k, "") for k in fields} for r in rows])

def parse_checkpoints(text):
    vals = tuple(int(x) for x in text.split(",") if x.strip())
    if not vals or any(v <= 0 for v in vals):
        raise SystemExit("checkpoints must be positive integers")
    return vals

def fasta_refs(path):
    refs = {}
    current = None
    if not path.exists():
        return refs
    for raw in path.read_text(encoding="utf-8").splitlines():
        if raw.startswith(">"):
            current = raw[1:].strip().split()[0]
            refs[current] = ""
        elif current is not None:
            refs[current] += raw.strip().upper()
    return refs

def neutral_records(input_dir, dataset_id, adapter_name):
    input_dir = Path(input_dir)
    manifest_path = input_dir / "cluster_manifest.tsv"
    reads_path = input_dir / "reads.tsv"
    if not manifest_path.exists() or not reads_path.exists():
        raise SystemExit(f"{adapter_name} expects cluster_manifest.tsv and reads.tsv in {input_dir}")
    manifest = read_tsv(manifest_path)
    reads = read_tsv(reads_path)
    refs = fasta_refs(input_dir / "references.fasta")
    by_cluster = {}
    line_ranges = {}
    for line_no, row in enumerate(reads, start=2):
        cid = str(row["cluster_id"])
        by_cluster.setdefault(cid, []).append(row)
        line_ranges.setdefault(cid, [line_no, line_no])[1] = line_no
    clusters = []
    for line_no, row in enumerate(manifest, start=2):
        cid = str(row["cluster_id"])
        ref = row.get("reference") or row.get("reference_sequence") or refs.get(cid, "")
        if not ref and refs:
            # Some neutral packs use dataset-local ordinal FASTA ids matching
            # cluster ids after string conversion.
            ref = refs.get(str(cid), "")
        clusters.append({
            "cluster_id": cid,
            "reference": ref.upper(),
            "reads": [(str(r.get("read_id", i)), (r.get("read_sequence") or r.get("sequence") or "").upper()) for i, r in enumerate(by_cluster.get(cid, []))],
            "manifest_line": line_no,
            "read_range": line_ranges.get(cid),
        })
    return clusters, {"cluster_manifest": manifest_path, "reads": reads_path}

def dnaformer_records(input_file, dataset_id, adapter_name):
    input_file = Path(input_file)
    if not input_file.exists():
        raise SystemExit(f"{adapter_name} input missing: {input_file}")
    clusters = []
    block = []
    malformed = 0
    def flush(block, cid):
        nonlocal malformed
        ref = block[0].strip().upper() if block else ""
        sep = block[1].strip() if len(block) > 1 else ""
        reads = [x.strip().upper() for x in block[2:] if x.strip()]
        reasons = []
        if not ref: reasons.append("missing_reference")
        if not sep or any(c != "*" for c in sep): reasons.append("bad_separator")
        if not reads: reasons.append("missing_reads")
        if any(c not in "ACGTN" for c in ref + "".join(reads)): reasons.append("invalid_alphabet")
        if reasons: malformed += 1
        clusters.append({
            "cluster_id": str(cid),
            "reference": ref,
            "reads": [(f"{dataset_id}_c{cid}_r{i}", seq) for i, seq in enumerate(reads)],
            "manifest_line": cid + 2,
            "read_range": None,
            "malformed_reason": ",".join(sorted(set(reasons))),
        })
    with input_file.open(encoding="utf-8", errors="replace", newline=None) as f:
        cid = 0
        for raw in f:
            line = raw.rstrip("\n\r")
            if line == "":
                if block:
                    flush(block, cid); cid += 1; block = []
            else:
                block.append(line)
        if block:
            flush(block, cid)
    if malformed:
        raise SystemExit(f"{adapter_name} found malformed clusters: {malformed}")
    return clusters, {"binned_file": input_file}

def prepare_from_records(records, source_paths, dataset_id, adapter_name, out_dir, checkpoints, expected_sha256=None):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    online = out_dir / "online_manifest.tsv"
    truth = out_dir / "offline_truth.tsv"
    payload = out_dir / "payload_cache.jsonl"
    row_keys = out_dir / "row_keys.tsv"
    rows = []
    uses = 0
    read_total = 0
    with online.open("w", encoding="utf-8", newline="") as of, truth.open("w", encoding="utf-8", newline="") as tf, payload.open("w", encoding="utf-8") as pf:
        ow = csv.DictWriter(of, delimiter="\t", fieldnames=["ordinal","row_key","dataset_id","cluster_id","prefix_t","read_id","sequence"], lineterminator="\n")
        tw = csv.DictWriter(tf, delimiter="\t", fieldnames=["row_key","dataset_id","reference_sequence"], lineterminator="\n")
        ow.writeheader(); tw.writeheader()
        ordinal = 0
        for rec in records:
            cid = rec["cluster_id"]
            reads = rec["reads"]
            read_total += len(reads)
            start_end = rec.get("read_range")
            if start_end:
                rr = f"reads.tsv:{start_end[0]}-{start_end[1]};first_t={{t}}"
            else:
                rr = "reads.tsv:file_order;first_t={t}"
            for t in checkpoints:
                if len(reads) >= t:
                    row_key = f"{dataset_id}|{cid}|{t}"
                    tw.writerow({"row_key": row_key, "dataset_id": dataset_id, "reference_sequence": rec["reference"]})
                    visible = []
                    for read_id, seq in reads[:t]:
                        ow.writerow({"ordinal": ordinal, "row_key": row_key, "dataset_id": dataset_id, "cluster_id": cid, "prefix_t": t, "read_id": read_id, "sequence": seq})
                        visible.append({"read_id": read_id, "sequence": seq})
                    pf.write(json.dumps({"row_key": row_key, "dataset_id": dataset_id, "cluster_id": cid, "prefix_t": t, "reference": rec["reference"], "reads": visible}, separators=(",", ":")) + "\n")
                    rows.append({"row_id": len(rows), "dataset_id": dataset_id, "cluster_id": cid, "prefix_t": t, "available_reads": len(reads), "used_reads": t, "row_key": row_key, "source_cluster_record": f"cluster_manifest.tsv:{rec['manifest_line']}", "source_read_range": rr.format(t=t)})
                    ordinal += 1
                    uses += t
    if len({r["row_key"] for r in rows}) != len(rows):
        raise SystemExit("duplicate row key detected")
    write_tsv(row_keys, rows, ["row_id","dataset_id","cluster_id","prefix_t","available_reads","used_reads","row_key","source_cluster_record","source_read_range"])
    source_rows = []
    for name, path in source_paths.items():
        if Path(path).exists() and Path(path).is_file():
            source_rows.append({"source": name, "path": str(path), "sha256": sha256_file(path), "expected_sha256": expected_sha256 if name == "binned_file" else "", "status": "verified" if not expected_sha256 or sha256_file(path) == expected_sha256 else "mismatch"})
    write_tsv(out_dir / "source_hash_manifest.tsv", source_rows, ["source","path","sha256","expected_sha256","status"])
    summary = [{"dataset_id": dataset_id, "adapter": adapter_name, "clusters": len(records), "reads": read_total, "prefix_rows": len(rows), "prefix_read_uses": uses, "row_key_sha256": sha256_file(row_keys), "online_manifest_sha256": sha256_file(online), "offline_truth_sha256": sha256_file(truth), "payload_cache_sha256": sha256_file(payload), "duplicate_row_key": 0, "missing_payload": 0}]
    write_tsv(out_dir / "scope_summary.tsv", summary)
    write_tsv(out_dir / "row_key_manifest.tsv", [{"path": "row_keys.tsv", "sha256": sha256_file(row_keys), "rows": len(rows)}])
    write_tsv(out_dir / "validation_report.tsv", [{"check": "adapter_preparation", "status": "pass", "adapter": adapter_name}, {"check": "truth_separated_from_online_manifest", "status": "pass", "adapter": adapter_name}])
    (out_dir / "adapter_log.txt").write_text(f"adapter={adapter_name}\ndataset_id={dataset_id}\n", encoding="utf-8")
    return summary[0]

def prepare_neutral_manifest_v1(input_path, dataset_id, out_dir, checkpoints, expected_sha256=None):
    return prepare_from_records(*neutral_records(input_path, dataset_id, "neutral_manifest_v1"), dataset_id, "neutral_manifest_v1", out_dir, checkpoints, expected_sha256)

def prepare_oligo0_v1(input_path, dataset_id, out_dir, checkpoints, expected_sha256=None):
    return prepare_from_records(*neutral_records(input_path, dataset_id, "oligo0_v1"), dataset_id, "oligo0_v1", out_dir, checkpoints, expected_sha256)

def prepare_ncomms19_365dishes_v1(input_path, dataset_id, out_dir, checkpoints, expected_sha256=None):
    return prepare_from_records(*neutral_records(input_path, dataset_id, "ncomms19_365dishes_v1"), dataset_id, "ncomms19_365dishes_v1", out_dir, checkpoints, expected_sha256)

def prepare_binned_nanopore_v1(input_path, dataset_id, out_dir, checkpoints, expected_sha256=None):
    return prepare_from_records(*neutral_records(input_path, dataset_id, "binned_nanopore_v1"), dataset_id, "binned_nanopore_v1", out_dir, checkpoints, expected_sha256)

def prepare_microsoft_cnr_processed_v1(input_path, dataset_id, out_dir, checkpoints, expected_sha256=None):
    return prepare_from_records(*neutral_records(input_path, dataset_id, "microsoft_cnr_processed_v1"), dataset_id, "microsoft_cnr_processed_v1", out_dir, checkpoints, expected_sha256)

def prepare_dnaformer_binned_v1(input_path, dataset_id, out_dir, checkpoints, expected_sha256=None):
    return prepare_from_records(*dnaformer_records(input_path, dataset_id, "dnaformer_binned_v1"), dataset_id, "dnaformer_binned_v1", out_dir, checkpoints, expected_sha256)

def prepare_trellisbma_datatoprocess_v1(input_path, dataset_id, out_dir, checkpoints, expected_sha256=None):
    return prepare_from_records(*neutral_records(input_path, dataset_id, "trellisbma_datatoprocess_v1"), dataset_id, "trellisbma_datatoprocess_v1", out_dir, checkpoints, expected_sha256)

ADAPTERS = {
    "neutral_manifest_v1": prepare_neutral_manifest_v1,
    "oligo0_v1": prepare_oligo0_v1,
    "ncomms19_365dishes_v1": prepare_ncomms19_365dishes_v1,
    "binned_nanopore_v1": prepare_binned_nanopore_v1,
    "microsoft_cnr_processed_v1": prepare_microsoft_cnr_processed_v1,
    "dnaformer_binned_v1": prepare_dnaformer_binned_v1,
    "trellisbma_datatoprocess_v1": prepare_trellisbma_datatoprocess_v1,
}

def main(argv=None):
    p = argparse.ArgumentParser(prog="abr-data")
    p.add_argument("--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="cmd", required=True)
    q = sub.add_parser("prepare")
    q.add_argument("--adapter", required=True, choices=sorted(ADAPTERS))
    q.add_argument("--input", required=True)
    q.add_argument("--dataset-id", required=True)
    q.add_argument("--output", required=True)
    q.add_argument("--checkpoints", default="1,2,3,5,10,20")
    q.add_argument("--expected-sha256", default="")
    args = p.parse_args(argv)
    checkpoints = parse_checkpoints(args.checkpoints)
    summary = ADAPTERS[args.adapter](args.input, args.dataset_id, args.output, checkpoints, args.expected_sha256 or None)
    print(json.dumps(summary, sort_keys=True))

if __name__ == "__main__":
    main()
