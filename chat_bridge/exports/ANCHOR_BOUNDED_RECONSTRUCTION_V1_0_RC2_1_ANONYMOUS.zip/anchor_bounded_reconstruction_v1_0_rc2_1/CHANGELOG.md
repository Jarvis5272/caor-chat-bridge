# Changelog

## 1.0.0-rc2.1

Externally verified data-ready clean export. Removes generated files from the anonymous package, fixes version metadata, replaces hidden payload-cache recipes with source-data recipes, and adds source-specific data adapter entry points.
