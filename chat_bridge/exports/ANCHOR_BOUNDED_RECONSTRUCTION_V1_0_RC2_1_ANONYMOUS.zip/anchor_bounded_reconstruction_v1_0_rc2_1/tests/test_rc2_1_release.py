
from __future__ import annotations
import csv, json, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KERNEL = ROOT / "build" / "abr-kernel"
PY = [sys.executable, "-m"]

def run(cmd, cwd=ROOT):
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=True)

def read_rows(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def make_neutral(base, bad=False):
    base.mkdir(parents=True, exist_ok=True)
    (base / "cluster_manifest.tsv").write_text("dataset_key\tcluster_id\treference_len\tnum_reads\nx\t0\t8\t4\nx\t1\t8\t1\n", encoding="utf-8")
    (base / "references.fasta").write_text(">0\nACGTACGT\n>1\nAAAACCCC\n", encoding="utf-8")
    (base / "reads.tsv").write_text("dataset_key\tcluster_id\tread_id\tread_sequence\nx\t0\tr0\tACGTACGT\nx\t0\tr1\tACGTACGT\nx\t0\tr2\tACGTACGT\nx\t0\tr3\tACGTACGT\nx\t1\tr4\tAAAACCCC\n", encoding="utf-8")

def make_binned(path, malformed=False):
    sep = "*****" if not malformed else "abc"
    path.write_text(f"ACGTACGT\n{sep}\nACGTACGT\nACGTACGT\nACGTACGT\nACGTACGT\n\nAAAACCCC\n*****\nAAAACCCC\n\n", encoding="utf-8")

class RC21Tests(unittest.TestCase):
    def test_algorithm_logic_source_coverage(self):
        src = (ROOT / "src/abr_kernel.cpp").read_text(encoding="utf-8")
        needles = {
            "cleaning": "clean_read",
            "kmer_occurrence": "build_from_seq",
            "aggregate_support": "anchor_support.update_from",
            "carrier_scoring": "select_carrier_fast",
            "tie_breaking": "stable_sort",
            "unique_anchors": "unique_positions_fast",
            "monotone_filtering": "out.emplace_back",
            "w_rejection": "ce - cs > W || re - rs > W",
            "drift_tie": "dom_sup - nd >= M",
            "m_plus_one": "dom_sup >= M+1",
            "rho_inclusive": ">= 0.35",
            "support_gap": "dom_sup - nd >= M",
            "exact_segment": "best_c",
            "subset_certificate": "read_subset",
            "diversity_guard": "pd >= ng",
            "cross_compatibility": "check_compat",
            "fallback": "chosen = car.substr",
            "assembly": "decode(rs, cs)",
            "stable_merge": "row_key",
            "duplicate_detection": "row_key",
            "missing_detection": "row_key",
        }
        for name, needle in needles.items():
            self.assertIn(needle, src, name)

    def test_receiver_determinism_and_parallel(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            outs = []
            for workers in (1, 2, 4):
                out = td / f"out_w{workers}.tsv"
                run(PY + ["anchor_bounded_reconstruction.receiver", "--manifest", "examples/tiny_manifest.tsv", "--output", str(out), "--workers", str(workers), "--kernel", str(KERNEL)])
                outs.append(out)
            self.assertEqual(outs[0].read_text(), outs[1].read_text())
            self.assertEqual(outs[0].read_text(), outs[2].read_text())
            self.assertEqual(read_rows(outs[0]), read_rows(ROOT / "examples/tiny_expected_output.tsv"))

    def test_evaluator(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "out.tsv"
            run(PY + ["anchor_bounded_reconstruction.receiver", "--manifest", "examples/tiny_manifest.tsv", "--output", str(out), "--workers", "1", "--kernel", str(KERNEL)])
            proc = run(PY + ["anchor_bounded_reconstruction.evaluate", "--pred", str(out), "--truth", "examples/tiny_truth.tsv"])
            self.assertIn("accuracy\t1.000000000000", proc.stdout)

    def test_all_adapters_and_contracts(self):
        adapters = ["neutral_manifest_v1","oligo0_v1","ncomms19_365dishes_v1","binned_nanopore_v1","microsoft_cnr_processed_v1","trellisbma_datatoprocess_v1"]
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            neutral = td / "neutral"; make_neutral(neutral)
            for adapter in adapters:
                out = td / adapter
                run(PY + ["anchor_bounded_reconstruction.data", "prepare", "--adapter", adapter, "--input", str(neutral), "--dataset-id", adapter, "--output", str(out), "--checkpoints", "1,2,3"])
                self.assertTrue((out / "online_manifest.tsv").exists())
                self.assertTrue((out / "offline_truth.tsv").exists())
                self.assertTrue((out / "payload_cache.jsonl").exists())
            binned = td / "binned.txt"; make_binned(binned)
            out = td / "dnaformer"
            run(PY + ["anchor_bounded_reconstruction.data", "prepare", "--adapter", "dnaformer_binned_v1", "--input", str(binned), "--dataset-id", "dna", "--output", str(out), "--checkpoints", "1,2,3"])
            self.assertEqual(read_rows(out / "scope_summary.tsv")[0]["clusters"], "2")

    def test_negative_adapter_cases(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            binned = td / "bad.txt"; make_binned(binned, malformed=True)
            proc = subprocess.run(PY + ["anchor_bounded_reconstruction.data", "prepare", "--adapter", "dnaformer_binned_v1", "--input", str(binned), "--dataset-id", "bad", "--output", str(td / "out")], cwd=ROOT, text=True, capture_output=True)
            self.assertNotEqual(proc.returncode, 0)
            neutral = td / "neutral"; make_neutral(neutral)
            out = td / "neutral_out"
            run(PY + ["anchor_bounded_reconstruction.data", "prepare", "--adapter", "neutral_manifest_v1", "--input", str(neutral), "--dataset-id", "n", "--output", str(out), "--checkpoints", "1,2"])
            rows = read_rows(out / "online_manifest.tsv")
            self.assertNotIn("reference_sequence", rows[0])

    def test_recipe_tiny_example(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            data_root = td / "data"; make_neutral(data_root / "tiny_neutral")
            recipe = td / "recipe.yaml"
            recipe.write_text(json.dumps({
                "benchmark_id": "tiny",
                "sources": [{"source_id":"tiny","adapter":"neutral_manifest_v1","input_path":"tiny_neutral","dataset_id":"tiny","checkpoints":[1,2,3],"expected_clusters":2,"expected_reads":5,"expected_prefix_rows":4,"expected_prefix_read_uses":7}],
                "expected_scope": {"prefix_rows": 4},
                "expected_combined_row_key_sha256": "",
                "number_lock": {}
            }), encoding="utf-8")
            # Compute expected combined hash after adapter preparation once.
            prep = td / "prep"
            run(PY + ["anchor_bounded_reconstruction.data", "prepare", "--adapter", "neutral_manifest_v1", "--input", str(data_root / "tiny_neutral"), "--dataset-id", "tiny", "--output", str(prep), "--checkpoints", "1,2,3"])
            import hashlib
            h = hashlib.sha256((prep / "row_keys.tsv").read_bytes()).hexdigest()
            obj = json.loads(recipe.read_text())
            obj["expected_combined_row_key_sha256"] = h
            recipe.write_text(json.dumps(obj), encoding="utf-8")
            run(PY + ["anchor_bounded_reconstruction.reproduce", "--recipe", str(recipe), "--data-root", str(data_root), "--work-dir", str(td / "run"), "--workers", "1", "--kernel", str(KERNEL)])
            self.assertTrue((td / "run" / "number_lock_comparison.tsv").exists())

if __name__ == "__main__":
    unittest.main()
