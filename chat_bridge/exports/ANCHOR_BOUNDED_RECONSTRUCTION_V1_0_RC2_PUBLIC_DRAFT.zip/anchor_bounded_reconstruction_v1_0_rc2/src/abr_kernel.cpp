// C++ V1 CECC fast kernel — integer kmer encoding, hash maps for speed
// Must match Python V1 output 100%
#include "blake2b.h"
#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <set>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cstdint>

using namespace std;

// ═══════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════
const int K = 7, W = 80, M = 2;
const double INCOMPAT_PENALTY = 0.6;

// ═══════════════════════════════════════════
// Fast integer kmer encoding: ACGT → 0,1,2,3
// 7-mer fits in 14 bits → uint16_t
// ═══════════════════════════════════════════
static const uint8_t BASE_BITS[256] = {
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,  0,255,  1,255,255,255,  2, 255,255,255,255,255,255,255,255, // A=0,C=1,G=2
    255,255,255,255,  3,255,255,255, 255,255,255,255,255,255,255,255, // T=3
    255,  0,255,  1,255,255,255,  2, 255,255,255,255,255,255,255,255, // a=0,c=1,g=2
    255,255,255,255,  3,255,255,255, 255,255,255,255,255,255,255,255, // t=3
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
    255,255,255,255,255,255,255,255, 255,255,255,255,255,255,255,255,
};

inline uint16_t encode_kmer(const char* seq, int pos) {
    uint16_t v = 0;
    for (int i = 0; i < K; i++) {
        uint8_t b = BASE_BITS[(uint8_t)seq[pos + i]];
        if (b > 3) return 0xFFFF;  // invalid base
        v = (v << 2) | b;
    }
    return v;
}

inline string decode_kmer(uint16_t v) {
    static const char bases[] = "ACGT";
    string s; s.resize(K);
    for (int i = K-1; i >= 0; i--) { s[i] = bases[v & 3]; v >>= 2; }
    return s;
}

// ═══════════════════════════════════════════
// Fast kmer_counter: returns (kmers_sorted, counts) preserving Python Counter order
// Python: Counter(seq[i:i+K] for i in range(len(seq)-K+1))
// Insertion order = sliding window left-to-right
// But then most_common(1) = first max-count in insertion order
// For anchor_support iteration: sum(kmer_support[mer] * count) — sum is commutative
// For carrier selection: sum(v * anchor_support.get(x,0) over kmers[i].items())
//   — items() iterates in insertion order (sliding window), sum is commutative
// Counter.update(other): preserves existing keys, appends new keys
// ═══════════════════════════════════════════

// OrderedCounter: tracks insertion order for Counter semantics
struct U16Counter {
    unordered_map<uint16_t, int> counts;
    vector<uint16_t> insertion_order;

    void clear() { counts.clear(); insertion_order.clear(); }

    void increment(uint16_t k) {
        auto it = counts.find(k);
        if (it == counts.end()) {
            counts[k] = 1;
            insertion_order.push_back(k);
        } else {
            it->second++;
        }
    }

    // Build from sequence in sliding-window order
    void build_from_seq(const string& seq) {
        clear();
        int n = (int)seq.size() - K + 1;
        for (int i = 0; i < n; i++) {
            uint16_t mer = encode_kmer(seq.c_str(), i);
            if (mer != 0xFFFF) increment(mer);
        }
    }

    // Update from another counter (preserves existing key order, appends new)
    void update_from(const U16Counter& other) {
        for (uint16_t k : other.insertion_order) {
            auto it = counts.find(k);
            if (it == counts.end()) {
                counts[k] = other.counts.at(k);
                insertion_order.push_back(k);
            } else {
                it->second += other.counts.at(k);
            }
        }
    }

    int get(uint16_t k) const {
        auto it = counts.find(k);
        return it != counts.end() ? it->second : 0;
    }

    bool empty() const { return counts.empty(); }
};

// ═══════════════════════════════════════════
// SHA-256 (from previous file, same implementation)
// ═══════════════════════════════════════════
namespace sha256 {
static const uint32_t Kk[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};
inline uint32_t rotr32(uint32_t x, int n) { return (x>>n)|(x<<(32-n)); }
struct Ctx { uint8_t d[64]; int dl; uint64_t bl; uint32_t s[8]; };
inline void init(Ctx& c) { c.dl=0;c.bl=0;c.s[0]=0x6a09e667;c.s[1]=0xbb67ae85;c.s[2]=0x3c6ef372;c.s[3]=0xa54ff53a;c.s[4]=0x510e527f;c.s[5]=0x9b05688c;c.s[6]=0x1f83d9ab;c.s[7]=0x5be0cd19; }
inline void xform(Ctx& c, const uint8_t d[64]) {
    uint32_t w[64]; for(int i=0;i<16;i++) w[i]=((uint32_t)d[i*4]<<24)|((uint32_t)d[i*4+1]<<16)|((uint32_t)d[i*4+2]<<8)|(uint32_t)d[i*4+3];
    for(int i=16;i<64;i++){uint32_t s0=rotr32(w[i-15],7)^rotr32(w[i-15],18)^(w[i-15]>>3);uint32_t s1=rotr32(w[i-2],17)^rotr32(w[i-2],19)^(w[i-2]>>10);w[i]=w[i-16]+s0+w[i-7]+s1;}
    uint32_t a=c.s[0],b=c.s[1],e=c.s[4],f=c.s[5],g=c.s[6],h=c.s[7],cc=c.s[2],dd=c.s[3];
    for(int i=0;i<64;i++){uint32_t S1=rotr32(e,6)^rotr32(e,11)^rotr32(e,25);uint32_t ch=(e&f)^((~e)&g);uint32_t t1=h+S1+ch+Kk[i]+w[i];uint32_t S0=rotr32(a,2)^rotr32(a,13)^rotr32(a,22);uint32_t maj=(a&b)^(a&cc)^(b&cc);uint32_t t2=S0+maj;h=g;g=f;f=e;e=dd+t1;dd=cc;cc=b;b=a;a=t1+t2;}
    c.s[0]+=a;c.s[1]+=b;c.s[2]+=cc;c.s[3]+=dd;c.s[4]+=e;c.s[5]+=f;c.s[6]+=g;c.s[7]+=h;
}
inline void update(Ctx& c, const uint8_t* d, size_t n) { for(size_t i=0;i<n;i++){c.d[c.dl++]=d[i]; if(c.dl==64){xform(c,c.d);c.bl+=512;c.dl=0;}} }
inline void fin(Ctx& c, uint8_t h[32]) {
    size_t i=c.dl;c.d[i++]=0x80; if(i>56){while(i<64)c.d[i++]=0; xform(c,c.d);i=0;} while(i<56)c.d[i++]=0; c.bl+=c.dl*8;
    for(int j=0;j<8;j++)c.d[63-j]=(uint8_t)(c.bl>>(j*8)); xform(c,c.d);
    for(int j=0;j<4;j++){h[j]=(c.s[0]>>(24-j*8))&0xff; h[j+4]=(c.s[1]>>(24-j*8))&0xff; h[j+8]=(c.s[2]>>(24-j*8))&0xff; h[j+12]=(c.s[3]>>(24-j*8))&0xff; h[j+16]=(c.s[4]>>(24-j*8))&0xff; h[j+20]=(c.s[5]>>(24-j*8))&0xff; h[j+24]=(c.s[6]>>(24-j*8))&0xff; h[j+28]=(c.s[7]>>(24-j*8))&0xff;}
}
inline string digest(const string& t){Ctx c;init(c);update(c,(const uint8_t*)t.data(),t.size());uint8_t h[32];fin(c,h);string o;o.reserve(64);static const char hex[]="0123456789abcdef";for(int i=0;i<32;i++){o+=hex[h[i]>>4];o+=hex[h[i]&15];}return o;}
}

// ═══════════════════════════════════════════
// Clean read (fast path)
// ═══════════════════════════════════════════
string clean_read(const string& read) {
    string out; out.reserve(read.size());
    for (char ch : read) {
        uint8_t b = BASE_BITS[(uint8_t)ch];
        if (b <= 3) out += "ACGT"[b];
    }
    return out;
}

// Reads state — per-cluster
struct ReadEntry { string id; string seq; U16Counter kmers; vector<pair<uint16_t,int>> unique_pos; /* (kmer, pos) */ };
struct ReadStateFast {
    vector<ReadEntry> reads;
    U16Counter anchor_support;
};

// ═══════════════════════════════════════════
// unique_positions: kmers appearing exactly once, returns vector of (kmer, first_pos)
// sorted by kmer (which is in uint16_t order = lex order since encoding preserves ACGT order)
// ═══════════════════════════════════════════
vector<pair<uint16_t,int>> unique_positions_fast(const string& seq) {
    // Track first occurrence and count
    unordered_map<uint16_t, int> first_pos;
    unordered_map<uint16_t, int> count;
    // Insertion order for stable iteration
    vector<uint16_t> order;

    int n = max(0, (int)seq.size() - K + 1);
    for (int i = 0; i < n; i++) {
        uint16_t mer = encode_kmer(seq.c_str(), i);
        if (mer == 0xFFFF) continue;
        auto it = first_pos.find(mer);
        if (it == first_pos.end()) {
            first_pos[mer] = i;
            count[mer] = 1;
            order.push_back(mer);
        } else {
            count[mer]++;
        }
    }

    // Filter unique and sort by kmer (uint16_t order = ACGT lex order)
    vector<pair<uint16_t,int>> result;
    for (uint16_t mer : order) {
        if (count[mer] == 1) result.emplace_back(mer, first_pos[mer]);
    }
    // Sort by kmer (lexicographic, matches Python dict key order)
    sort(result.begin(), result.end(),
         [](const auto& a, const auto& b) { return a.first < b.first; });
    return result;
}

// ExtractAnchors with int kmers
vector<pair<int,int>> ExtractAnchors_fast(const string& carrier, const string& read) {
    auto cp_vec = unique_positions_fast(carrier);
    auto rp_vec = unique_positions_fast(read);
    // Build map for fast lookup
    unordered_map<uint16_t, int> rp_map;
    for (const auto& [mer, pos] : rp_vec) rp_map[mer] = pos;

    // Build pairs in cp order (sorted by kmer)
    vector<pair<int,int>> pairs;
    for (const auto& [mer, cpos] : cp_vec) {
        auto it = rp_map.find(mer);
        if (it != rp_map.end()) {
            pairs.emplace_back(cpos, it->second);
        }
    }
    // Stable sort by (carrier_pos, read_pos)
    stable_sort(pairs.begin(), pairs.end(),
                [](const auto& a, const auto& b) {
                    if (a.first != b.first) return a.first < b.first;
                    return a.second < b.second;
                });
    // Non-crossing filter
    vector<pair<int,int>> out; out.reserve(pairs.size());
    int lc = -1, lr = -1;
    for (auto [cx, rx] : pairs) {
        if (cx > lc && rx > lr) { out.emplace_back(cx, rx); lc = cx; lr = rx; }
    }
    return out;
}

int median_len_fast(const vector<ReadEntry>& reads) {
    if (reads.empty()) return 0;
    vector<int> lens; lens.reserve(reads.size());
    for (const auto& r : reads) lens.push_back((int)r.seq.size());
    sort(lens.begin(), lens.end());
    return lens[lens.size() / 2];
}

int read_subset(const string& rid, int sid) {
    return blake2b::hash_single_byte(rid + ":" + to_string(sid)) & 1;
}

// ═══════════════════════════════════════════
// Carrier selection
// ═══════════════════════════════════════════
struct CarrierResult { int idx; const string* seq; int score; int tie_count; };

CarrierResult select_carrier_fast(ReadStateFast& state) {
    if (state.reads.empty()) return {-1, nullptr, 0, 0};
    if (state.reads.size() == 1) return {0, &state.reads[0].seq, 0, 1};

    int med = median_len_fast(state.reads);
    struct S { int i, sc, t1, t2, t3; };
    vector<S> scores; scores.reserve(state.reads.size());
    for (int i = 0; i < (int)state.reads.size(); i++) {
        int sc = 0;
        for (uint16_t mer : state.reads[i].kmers.insertion_order) {
            int cnt = state.reads[i].kmers.counts.at(mer);
            sc += cnt * state.anchor_support.get(mer);
        }
        int l = (int)state.reads[i].seq.size();
        scores.push_back({i, sc, -abs(l-med), -l, -i});
    }
    auto best = max_element(scores.begin(), scores.end(),
        [](const S& a, const S& b) {
            if(a.sc!=b.sc) return a.sc<b.sc;
            if(a.t1!=b.t1) return a.t1<b.t1;
            if(a.t2!=b.t2) return a.t2<b.t2;
            return a.t3<b.t3;
        });
    int w = 0;
    for (const auto& s : scores) if(s.sc==best->sc&&s.t1==best->t1&&s.t2==best->t2) w++;
    return {best->i, &state.reads[best->i].seq, best->sc, w};
}

// ═══════════════════════════════════════════
// Evidence building
// ═══════════════════════════════════════════
struct Obs {
    string segment; int read_index; string read_id;
    int subset0, subset1, subset2;
    int geo0, geo1, geo2, geo3, pair_index;
};
struct EvidenceFast {
    // Use ordered map for sorted_obs — key is (start, end)
    map<pair<int,int>, vector<Obs>> observations;
    int anchor_count=0, anchor_pair_count=0, ambiguous=0, unmapped=0;
};

EvidenceFast build_evidence_fast(const ReadStateFast& state, const string& carrier) {
    EvidenceFast ev;
    for (int ri = 0; ri < (int)state.reads.size(); ri++) {
        const auto& [rid, seq, kmers, up] = state.reads[ri];
        auto anchors = ExtractAnchors_fast(carrier, seq);
        ev.anchor_count += (int)anchors.size();
        if (anchors.empty()) { ev.unmapped++; continue; }

        vector<pair<int,int>> expanded;
        expanded.reserve(anchors.size() + 2);
        expanded.emplace_back(-K, -K);
        for (auto [cx, rx] : anchors) expanded.emplace_back(cx, rx);
        expanded.emplace_back((int)carrier.size(), (int)seq.size());

        for (int pi = 0; pi < (int)expanded.size() - 1; pi++) {
            auto [cp0, rp0] = expanded[pi];
            auto [cp1, rp1] = expanded[pi + 1];
            int cs = cp0 < 0 ? 0 : cp0 + K;
            int rs = rp0 < 0 ? 0 : rp0 + K;
            int ce = cp1 >= (int)carrier.size() ? (int)carrier.size() : cp1;
            int re = rp1 >= (int)seq.size() ? (int)seq.size() : rp1;
            if (cs > ce || rs > re || ce - cs > W || re - rs > W) { ev.ambiguous++; continue; }
            Obs ob;
            ob.segment = seq.substr(rs, re - rs);
            ob.read_index = ri; ob.read_id = rid;
            ob.subset0 = read_subset(rid, 0);
            ob.subset1 = read_subset(rid, 1);
            ob.subset2 = read_subset(rid, 2);
            ob.geo0 = cp0; ob.geo1 = cp1; ob.geo2 = rp0 - cp0; ob.geo3 = rp1 - cp1;
            ob.pair_index = pi;
            ev.observations[{cs, ce}].push_back(move(ob));
            ev.anchor_pair_count++;
        }
    }
    return ev;
}

// ═══════════════════════════════════════════
// DICEC local decision
// ═══════════════════════════════════════════
struct DI { string var; bool accept; int cp, ss, sup; string mode; double pd, nd; };

pair<string, DI> dicec_local_fast(const string& car_seg, const vector<Obs>& items) {
    int clen = (int)car_seg.size();
    // drift_modes with insertion order
    map<string, vector<const Obs*>> drift_modes;
    vector<string> mode_order;

    for (const auto& it : items) {
        int drift = (int)it.segment.size() - clen;
        string mode = drift == 0 ? "no_drift" : (drift > 0 ? "insertion_drift" : "deletion_drift");
        if (drift_modes.find(mode) == drift_modes.end()) mode_order.push_back(mode);
        drift_modes[mode].push_back(&it);
    }

    map<string, int> ds;
    for (const auto& kv : drift_modes) ds[kv.first] = (int)kv.second.size();
    int total = (int)items.size();
    int nd = ds.count("no_drift") ? ds["no_drift"] : 0;

    vector<pair<int,string>> alts;
    for (const auto& kv : ds) if (kv.first != "no_drift") alts.emplace_back(kv.second, kv.first);
    sort(alts.begin(), alts.end(), greater<pair<int,string>>());

    DI info{"", false, 0, 0, 0, "none", 0.0, 0.0};
    info.var = car_seg;

    if (alts.empty()) return {car_seg, info};
    int dom_sup = alts[0].first;
    string dom = alts[0].second;

    if (!(dom_sup >= M+1 && (double)dom_sup/max(1,total) >= 0.35 && dom_sup - nd >= M)) {
        info.sup = dom_sup; info.mode = dom; return {car_seg, info};
    }

    const auto& mode_items = drift_modes[dom];
    // Counter with insertion order
    unordered_map<string, int> mc;
    vector<string> mc_order;
    for (const auto* it : mode_items) {
        auto mit = mc.find(it->segment);
        if (mit == mc.end()) { mc[it->segment] = 1; mc_order.push_back(it->segment); }
        else mit->second++;
    }
    // most_common(1): first max-count in insertion order
    const string* best_seg = nullptr; int best_c = -1;
    for (const auto& seg : mc_order) {
        int c = mc[seg];
        if (c > best_c) { best_c = c; best_seg = &seg; }
    }

    if (!best_seg || *best_seg == car_seg || best_c < M) {
        info.sup = best_c; info.mode = dom; return {car_seg, info};
    }

    // Certificate
    int s0=0,s1=0,s2=0;
    for (const auto* it : mode_items) {
        if (it->segment == *best_seg) { s0|=it->subset0; s1|=it->subset1; s2|=it->subset2; }
    }
    int sc = s0+s1+s2;
    info.cp = sc >= 2 ? 1 : 0; info.ss = sc; info.sup = best_c; info.mode = dom; info.var = *best_seg;
    if (!info.cp) { info.var = car_seg; info.accept = false; return {car_seg, info}; }

    // Diversity
    auto div = [&](const string& s) {
        set<int> subs;
        for (const auto& it : items) if (it.segment == s) { subs.insert(it.subset0); subs.insert(it.subset1); subs.insert(it.subset2); }
        return (double)subs.size() / 3.0;
    };
    double pd = div(*best_seg), ng = div(car_seg);
    info.pd = pd; info.nd = ng;
    if (pd >= ng) { info.accept = true; return {*best_seg, info}; }
    else { info.var = car_seg; info.accept = false; return {car_seg, info}; }
}

// ═══════════════════════════════════════════
// Cross-event state
// ═══════════════════════════════════════════
struct CrossState {
    map<pair<pair<int,int>,pair<int,int>>, map<pair<string,string>, int>> cross_events;
};

void register_cross(CrossState& st, pair<int,int> sk, const string& var,
                    const set<int>& idxs,
                    const vector<pair<pair<int,int>, vector<Obs>>>& all) {
    for (const auto& [ok, oi] : all) {
        if (ok == sk) continue;
        if (abs(sk.first - ok.first) > W) continue;
        for (const auto& it : oi) {
            if (idxs.count(it.read_index)) {
                auto pk = make_pair(min(sk,ok), max(sk,ok));
                auto vp = sk < ok ? make_pair(var, it.segment) : make_pair(it.segment, var);
                st.cross_events[pk][vp]++;
            }
        }
    }
}

struct Compat { bool ok; double ac; int cs; };
Compat check_compat(const CrossState& st, pair<int,int> sk, const string& var,
                    const vector<pair<pair<int,int>, string>>& adj) {
    if (adj.empty()) return {true, 1.0, 0};
    double cs = 0.0; int tc = 0;
    for (const auto& [ak, av] : adj) {
        auto pk = make_pair(min(sk,ak), max(sk,ak));
        auto it = st.cross_events.find(pk);
        if (it == st.cross_events.end() || it->second.empty()) { tc++; cs += 0.5; continue; }
        int tp = 0; for (const auto& kv : it->second) tp += kv.second;
        auto vp = sk < ak ? make_pair(var, av) : make_pair(av, var);
        auto vit = it->second.find(vp);
        int pc = vit != it->second.end() ? vit->second : 0;
        cs += tp > 0 ? (double)pc/tp : 0.0; tc++;
    }
    if (tc == 0) return {true,1.0,0};
    double ac = cs/tc;
    int xs = 0;
    for (const auto& [ak,_] : adj) {
        auto pk = make_pair(min(sk,ak), max(sk,ak));
        if (st.cross_events.count(pk) && !st.cross_events.at(pk).empty()) xs++;
    }
    return {xs >= 1 && ac >= (1.0-INCOMPAT_PENALTY), ac, xs};
}

// ═══════════════════════════════════════════
// Full decode
// ═══════════════════════════════════════════
struct DecodeOut { string output, hash; int len; };

DecodeOut decode(ReadStateFast& rs, CrossState& cs) {
    DecodeOut out;
    auto car_res = select_carrier_fast(rs);
    if (car_res.idx < 0 || !car_res.seq || car_res.seq->empty()) {
        out.output = ""; out.hash = sha256::digest(""); out.len = 0; return out;
    }
    const string& car = *car_res.seq;
    auto ev = build_evidence_fast(rs, car);

    // sorted_obs: copy from ordered map
    vector<pair<pair<int,int>, vector<Obs>>> sorted_obs;
    sorted_obs.reserve(ev.observations.size());
    for (auto& kv : ev.observations) sorted_obs.emplace_back(kv.first, move(kv.second));
    // Already sorted by map key order: (start, end) — but need stable sort by (start, length)
    stable_sort(sorted_obs.begin(), sorted_obs.end(),
        [](const auto& a, const auto& b) {
            if (a.first.first != b.first.first) return a.first.first < b.first.first;
            return (a.first.second - a.first.first) < (b.first.second - b.first.first);
        });

    // Phase 1: DICEC local
    map<pair<int,int>, pair<string, DI>> local;
    for (const auto& [key, items] : sorted_obs) {
        string csg = car.substr(key.first, key.second - key.first);
        auto [var, info] = dicec_local_fast(csg, items);
        local[key] = {var, info};
    }

    // Phase 2: register cross
    for (const auto& [key, items] : sorted_obs) {
        auto& [var, info] = local[key];
        if (info.accept && info.cp) {
            set<int> idxs;
            for (const auto& it : items) if (it.segment == var) idxs.insert(it.read_index);
            register_cross(cs, key, var, idxs, sorted_obs);
        }
    }

    // Phase 3: output
    vector<string> pieces; int cursor = 0;
    vector<pair<int,int>> skeys;
    for (const auto& [k,_] : sorted_obs) skeys.push_back(k);

    for (int isk = 0; isk < (int)sorted_obs.size(); isk++) {
        auto [st, en] = sorted_obs[isk].first;
        if (st < cursor) continue;
        if (st > cursor) pieces.push_back(car.substr(cursor, st - cursor));

        // adjacent decisions
        vector<pair<pair<int,int>, string>> adj;
        if (isk > 0) {
            auto pk = skeys[isk-1]; auto it = local.find(pk);
            if (it != local.end() && it->second.second.accept && it->second.second.cp) adj.emplace_back(pk, it->second.first);
        }
        if (isk < (int)skeys.size() - 1) {
            auto nk = skeys[isk+1]; auto it = local.find(nk);
            if (it != local.end() && it->second.second.accept && it->second.second.cp) adj.emplace_back(nk, it->second.first);
        }

        auto& [variant, info] = local[{st, en}];
        string chosen = variant;
        if (info.accept && info.cp && !adj.empty()) {
            auto comp = check_compat(cs, {st,en}, variant, adj);
            if (!comp.ok) chosen = car.substr(st, en-st);
        }
        pieces.push_back(chosen);
        cursor = en;
    }
    if (cursor < (int)car.size()) pieces.push_back(car.substr(cursor));

    out.output.clear();
    for (const auto& p : pieces) out.output += p;
    out.hash = sha256::digest(out.output);
    out.len = (int)out.output.size();
    return out;
}

// ═══════════════════════════════════════════
// Main
// ═══════════════════════════════════════════
int main() {
    ios::sync_with_stdio(false); cin.tie(nullptr);
    string line;
    // Audit-only serializer: expose the already-computed sequence without
    // changing any reconstruction state or decision logic.
    cout << "row_key\toutput_hash\toutput_sequence\toutput_len\tstatus\texpected_hash\n";
    long cnt = 0;

    while (getline(cin, line)) {
        if (line.empty() || line[0] == '#') continue;
        if (line.rfind("ROW\t", 0) != 0) continue;

        size_t p1 = line.find('\t');
        size_t p2 = line.find('\t', p1+1);
        size_t p3 = line.find('\t', p2+1);
        size_t p4 = line.find('\t', p3+1);
        if (p1 == string::npos || p2 == string::npos || p3 == string::npos) continue;
        string rk = line.substr(p1+1, p2-p1-1);
        int pt = stoi(line.substr(p2+1, p3-p2-1));
        int nr = stoi(line.substr(p3+1, p4-p3-1));
        string eh;
        if (p4 != string::npos) eh = line.substr(p4+1);

        ReadStateFast rs;
        for (int i = 0; i < nr && getline(cin, line); i++) {
            size_t q1 = line.find('\t');
            size_t q2 = line.find('\t', q1+1);
            if (q1 == string::npos || q2 == string::npos) continue;
            string rid = line.substr(q1+1, q2-q1-1);
            string rseq = line.substr(q2+1);
            if (i < pt) {
                ReadEntry re;
                re.id = rid;
                re.seq = clean_read(rseq);
                re.kmers.build_from_seq(re.seq);
                re.unique_pos = unique_positions_fast(re.seq);
                rs.reads.push_back(move(re));
                rs.anchor_support.update_from(rs.reads.back().kmers);
            }
        }

        CrossState cs;
        auto out = decode(rs, cs);
        cout << rk << "\t" << out.hash << "\t" << out.output << "\t"
             << out.len << "\tcompleted\t" << eh << "\n";

        cnt++;
        // progress tracking silent for clean stdout; use stderr only if needed
    }
    // Final count: not emitted to avoid polluting parse
    return 0;
}
