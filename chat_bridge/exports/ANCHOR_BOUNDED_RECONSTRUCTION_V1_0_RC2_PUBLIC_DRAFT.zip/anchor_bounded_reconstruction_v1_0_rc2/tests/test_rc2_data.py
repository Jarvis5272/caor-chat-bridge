import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class RC2DataTests(unittest.TestCase):
    def test_schema_files_exist(self):
        self.assertTrue((ROOT / "schemas/ONLINE_MANIFEST_SCHEMA.tsv").exists())
        self.assertTrue((ROOT / "schemas/OFFLINE_TRUTH_SCHEMA.tsv").exists())

    def test_payload_cache_mode_ignores_reference(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            cache = td / "cache.jsonl"
            row = {"row_key":"x|0|1","dataset_id":"x","cluster_id":"0","prefix_t":1,"reference":"AAAA","reads":[{"read_id":"r0","sequence":"ACGTACGT"}]}
            cache.write_text(json.dumps(row) + "\n", encoding="utf-8")
            out = td / "out.tsv"
            subprocess.check_call([sys.executable, "-m", "anchor_bounded_reconstruction.receiver", "--payload-cache-jsonl", str(cache), "--output", str(out), "--workers", "1", "--kernel", "build/abr-kernel"], cwd=ROOT)
            rows = list(csv.DictReader(open(out, encoding="utf-8"), delimiter="\t"))
            self.assertEqual(rows[0]["reconstructed_sequence"], "ACGTACGT")

    def test_abr_data_help(self):
        proc = subprocess.run([sys.executable, "-m", "anchor_bounded_reconstruction.data", "prepare", "--help"], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("dnaformer_binned_v1", proc.stdout)
