import csv
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KERNEL = ROOT / "build/abr-kernel"

def read_rows(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def run_receiver(workers, out):
    cmd = [
        sys.executable,
        "-m",
        "anchor_bounded_reconstruction.receiver",
        "--manifest",
        "examples/tiny_manifest.tsv",
        "--output",
        str(out),
        "--workers",
        str(workers),
        "--kernel",
        str(KERNEL),
    ]
    subprocess.check_call(cmd, cwd=ROOT)

class ReleaseTests(unittest.TestCase):
    def test_source_constants_and_boundaries(self):
        src = (ROOT / "src/abr_kernel.cpp").read_text(encoding="utf-8")
        checks = [
            "const int K = 7, W = 80, M = 2;",
            "dom_sup >= M+1",
            "(double)dom_sup/max(1,total) >= 0.35",
            "dom_sup - nd >= M",
            "ce - cs > W || re - rs > W",
            "stable_sort(pairs.begin(), pairs.end()",
            "stable_sort(sorted_obs.begin(), sorted_obs.end()",
            "sc >= 2",
            "pd >= ng",
            "1.0-INCOMPAT_PENALTY",
            "select_carrier_fast",
            "ExtractAnchors_fast",
            "decode(rs, cs)",
            "read_subset(rid, 0)",
        ]
        for needle in checks:
            self.assertIn(needle, src)

    def test_regression_and_determinism(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            out1 = tmp / "out_w1.tsv"
            out1b = tmp / "out_w1b.tsv"
            run_receiver(1, out1)
            run_receiver(1, out1b)
            self.assertEqual(out1.read_text(), out1b.read_text())
            self.assertEqual(read_rows(out1), read_rows(ROOT / "examples/tiny_expected_output.tsv"))

    def test_parallel_invariance(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            out1 = tmp / "out_w1.tsv"
            out2 = tmp / "out_w2.tsv"
            out4 = tmp / "out_w4.tsv"
            run_receiver(1, out1)
            run_receiver(2, out2)
            run_receiver(4, out4)
            self.assertEqual(out1.read_text(), out2.read_text())
            self.assertEqual(out1.read_text(), out4.read_text())

    def test_evaluator(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "out.tsv"
            run_receiver(1, out)
            proc = subprocess.run([
                sys.executable,
                "-m",
                "anchor_bounded_reconstruction.evaluate",
                "--pred",
                str(out),
                "--truth",
                "examples/tiny_truth.tsv",
            ], cwd=ROOT, text=True, capture_output=True, check=True)
            self.assertIn("accuracy\t1.000000000000", proc.stdout)

if __name__ == "__main__":
    unittest.main()
