# Anchor-Bounded Reconstruction v1.0-rc1

This is a clean release candidate for Anchor-Bounded Reconstruction and deterministic row-parallel receiver execution.

## Scope

The package reconstructs already-clustered DNA-storage prefix rows. It does not perform raw-signal basecalling, end-to-end clustering, confidence calibration, early stopping, or incremental cross-prefix state reuse.

## Defaults

`K=7`, `W=80`, `M=2`, and `rho=0.35`.

## Build

```bash
cmake -S . -B build
cmake --build build
```

## Quick start

```bash
python -m anchor_bounded_reconstruction.receiver --manifest examples/tiny_manifest.tsv --output example_output.tsv --workers 1 --config configs/default.yaml --kernel build/abr-kernel
python -m anchor_bounded_reconstruction.receiver --manifest examples/tiny_manifest.tsv --output example_output_w4.tsv --workers 4 --config configs/default.yaml --kernel build/abr-kernel
```

`P` / `--workers` is an execution parameter. It does not change row-level reconstruction.

## Input

Manifest TSV fields: `row_key`, `dataset_id`, `cluster_id`, `prefix_t`, `read_id`, `sequence`.
The receiver uses only the listed reads; references are not part of online reconstruction input.

## Output

TSV fields: `row_key`, `dataset_id`, `cluster_id`, `prefix_t`, `reconstructed_sequence`, `status`.

## Citation

Citation metadata is intentionally templated for double-blind review. Fill it after review policy allows public identity.
