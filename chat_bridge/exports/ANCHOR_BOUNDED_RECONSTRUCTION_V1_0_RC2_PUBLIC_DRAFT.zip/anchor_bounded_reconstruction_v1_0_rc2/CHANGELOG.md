# Changelog

## v1.0-rc1

- Clean release extraction of frozen row-level kernel and deterministic receiver wrapper.
