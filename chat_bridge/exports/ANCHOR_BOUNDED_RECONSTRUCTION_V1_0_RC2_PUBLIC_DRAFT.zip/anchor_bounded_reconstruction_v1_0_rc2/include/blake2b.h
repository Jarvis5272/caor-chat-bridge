// BLAKE2b reference implementation — minimal, for exact match with Python hashlib.blake2b
// Based on RFC 7693: The BLAKE2 Cryptographic Hash and Message Authentication Code (MAC)
// https://tools.ietf.org/html/rfc7693
#pragma once
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>

namespace blake2b {

// BLAKE2b state
struct state {
    uint64_t h[8];
    uint64_t t[2];   // byte counter
    uint64_t f[2];   // finalization flags
    uint8_t  buf[128];
    size_t   buflen;
    size_t   outlen;
};

// IV for BLAKE2b
static const uint64_t iv[8] = {
    0x6a09e667f3bcc908ULL, 0xbb67ae8584caa73bULL,
    0x3c6ef372fe94f82bULL, 0xa54ff53a5f1d36f1ULL,
    0x510e527fade682d1ULL, 0x9b05688c2b3e6c1fULL,
    0x1f83d9abfb41bd6bULL, 0x5be0cd19137e2179ULL
};

// Sigma permutation table
static const uint8_t sigma[12][16] = {
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
    {14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3},
    {11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4},
    {7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8},
    {9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13},
    {2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9},
    {12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11},
    {13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10},
    {6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5},
    {10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0},
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
    {14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3}
};

inline uint64_t rotr64(uint64_t x, int n) { return (x >> n) | (x << (64 - n)); }

#define G(r,i,a,b,c,d) do {              \
    a = a + b + m[sigma[r][2*i+0]];      \
    d = rotr64(d ^ a, 32);               \
    c = c + d;                           \
    b = rotr64(b ^ c, 24);               \
    a = a + b + m[sigma[r][2*i+1]];      \
    d = rotr64(d ^ a, 16);               \
    c = c + d;                           \
    b = rotr64(b ^ c, 63);               \
} while(0)

inline void compress(state& S, const uint8_t block[128]) {
    uint64_t m[16];
    uint64_t v[16];
    for (int i = 0; i < 16; i++)
        m[i] = ((uint64_t*)block)[i];  // assumes little-endian (x86_64)

    for (int i = 0; i < 8; i++)  v[i] = S.h[i];
    for (int i = 0; i < 8; i++)  v[i+8] = iv[i];
    v[12] ^= S.t[0];
    v[13] ^= S.t[1];
    v[14] ^= S.f[0];
    v[15] ^= S.f[1];

    for (int r = 0; r < 12; r++) {
        G(r,0, v[0],v[4],v[8], v[12]);
        G(r,1, v[1],v[5],v[9], v[13]);
        G(r,2, v[2],v[6],v[10],v[14]);
        G(r,3, v[3],v[7],v[11],v[15]);
        G(r,4, v[0],v[5],v[10],v[15]);
        G(r,5, v[1],v[6],v[11],v[12]);
        G(r,6, v[2],v[7],v[8], v[13]);
        G(r,7, v[3],v[4],v[9], v[14]);
    }
    for (int i = 0; i < 8; i++) S.h[i] ^= v[i] ^ v[i+8];
}

inline void init(state& S, size_t outlen) {
    // Initialize with IV (not zero!)
    for (int i = 0; i < 8; i++) S.h[i] = iv[i];
    S.outlen = outlen;
    // Parameter block XOR: digest_size=outlen, key_len=0, fanout=1, depth=1
    // le64([outlen, 0, 1, 1, 0,0,0,0]) = 0x01010000 | outlen
    S.h[0] ^= 0x01010000 ^ (uint64_t)outlen;
    S.t[0] = S.t[1] = 0;
    S.f[0] = S.f[1] = 0;
    S.buflen = 0;
}

inline void update(state& S, const uint8_t* data, size_t len) {
    S.t[0] += len;
    if (S.t[0] < len) S.t[1]++;  // carry

    if (S.buflen > 0) {
        size_t fill = 128 - S.buflen;
        if (len < fill) {
            memcpy(S.buf + S.buflen, data, len);
            S.buflen += len;
            return;
        }
        memcpy(S.buf + S.buflen, data, fill);
        compress(S, S.buf);
        data += fill; len -= fill;
        S.buflen = 0;
    }

    while (len >= 128) {
        compress(S, data);
        data += 128; len -= 128;
    }
    if (len > 0) {
        memcpy(S.buf, data, len);
        S.buflen = len;
    }
}

inline void finalize(state& S, uint8_t* out) {
    S.f[0] = 0xffffffffffffffffULL;  // last block
    memset(S.buf + S.buflen, 0, 128 - S.buflen);
    compress(S, S.buf);
    for (size_t i = 0; i < S.outlen; i++)
        out[i] = (uint8_t)(S.h[i/8] >> (8*(i%8)));
}

// Convenience: compute full blake2b hash
inline std::vector<uint8_t> hash(const uint8_t* data, size_t len, size_t outlen) {
    state S;
    init(S, outlen);
    update(S, data, len);
    std::vector<uint8_t> out(outlen);
    finalize(S, out.data());
    return out;
}

// Convenience: single byte hash (what V1 uses for subset)
inline uint8_t hash_single_byte(const std::string& input) {
    auto h = hash((const uint8_t*)input.data(), input.size(), 1);
    return h[0];
}

} // namespace blake2b
