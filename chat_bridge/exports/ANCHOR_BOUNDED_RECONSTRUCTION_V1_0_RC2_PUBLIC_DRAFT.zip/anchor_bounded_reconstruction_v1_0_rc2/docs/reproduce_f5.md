Run `abr-reproduce --recipe recipes/f5.yaml --data-root <data-root> --work-dir runs/f5 --workers 16`.
