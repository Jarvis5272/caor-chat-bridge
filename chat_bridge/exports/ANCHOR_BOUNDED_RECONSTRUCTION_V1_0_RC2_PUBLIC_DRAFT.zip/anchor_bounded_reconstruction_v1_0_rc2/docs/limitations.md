# limitations.md

No confidence calibration, early stopping, raw-signal processing, clustering, or baseline implementation is included.
