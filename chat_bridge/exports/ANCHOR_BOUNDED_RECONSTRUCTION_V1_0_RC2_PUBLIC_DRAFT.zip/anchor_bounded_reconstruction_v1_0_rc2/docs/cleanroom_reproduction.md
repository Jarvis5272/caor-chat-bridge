Unzip in a clean directory, build `abr-kernel`, set PYTHONPATH to the package `python/` directory, and pass data-root explicitly.
