Check source hashes, row-key hashes, missing rows, and duplicate rows first.
