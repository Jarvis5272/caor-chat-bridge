# reproducibility.md

Use the default config and record worker count, kernel SHA-256, and manifest SHA-256.
