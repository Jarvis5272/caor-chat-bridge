# Data contract

`abr-online-manifest-v1` contains only row identity and visible reads. It must not contain reference, truth, edit distance, baseline output, or future reads.

`abr-offline-truth-v1` is separate and is consumed only by `abr-evaluate`.
