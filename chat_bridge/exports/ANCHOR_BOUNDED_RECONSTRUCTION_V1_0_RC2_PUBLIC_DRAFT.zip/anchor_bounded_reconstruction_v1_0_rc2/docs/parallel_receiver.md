# parallel_receiver.md

The receiver partitions immutable prefix rows, invokes the same row-level kernel, then stable-merges by canonical row order.
