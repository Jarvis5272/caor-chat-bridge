# anonymized_artifact_instructions.md

Do not add author names, institutions, GitHub owners, local paths, or private acknowledgments before double-blind review ends.
