# public_github_release_checklist.md

After double-blind restrictions end: fill LICENSE, AUTHORS, CITATION.cff, repository URL, and release DOI.
