# algorithm.md

Algorithm 1 is implemented by `src/abr_kernel.cpp`. Algorithm 2 is implemented by `python/anchor_bounded_reconstruction/receiver.py`.
