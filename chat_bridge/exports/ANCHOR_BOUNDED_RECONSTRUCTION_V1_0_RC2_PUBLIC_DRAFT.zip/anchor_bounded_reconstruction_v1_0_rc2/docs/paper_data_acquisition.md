Paper datasets are not bundled. Use the DOI/source manifests and verify hashes before running recipes.
