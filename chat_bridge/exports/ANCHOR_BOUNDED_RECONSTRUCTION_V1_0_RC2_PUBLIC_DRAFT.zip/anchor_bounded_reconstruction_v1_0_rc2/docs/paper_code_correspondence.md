# paper_code_correspondence.md

See audit `PAPER_CODE_CONSISTENCY_MATRIX.tsv` for paper-code mapping.
