# input_contract.md

References are excluded from online reconstruction input. Truth files are only used by the optional offline evaluator.
