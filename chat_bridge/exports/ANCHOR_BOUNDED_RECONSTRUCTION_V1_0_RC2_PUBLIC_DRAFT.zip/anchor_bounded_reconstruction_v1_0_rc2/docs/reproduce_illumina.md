Run `abr-reproduce --recipe recipes/illumina.yaml --data-root <data-root> --work-dir runs/illumina --workers 16`.
