import argparse
import csv
import json
from collections import defaultdict

def ed(a, b):
    start = 0
    la, lb = len(a), len(b)
    while start < la and start < lb and a[start] == b[start]:
        start += 1
    a = a[start:]
    b = b[start:]
    while a and b and a[-1] == b[-1]:
        a = a[:-1]
        b = b[:-1]
    if not a:
        return len(b)
    if not b:
        return len(a)
    if len(b) > len(a):
        a, b = b, a
    m = len(b)
    peq = {}
    for i, ch in enumerate(b):
        peq[ch] = peq.get(ch, 0) | (1 << i)
    pv = ~0
    mv = 0
    score = m
    high_bit = 1 << (m - 1)
    for ch in a:
        eq = peq.get(ch, 0)
        xv = eq | mv
        xh = (((eq & pv) + pv) ^ pv) | eq
        ph = mv | ~(xh | pv)
        mh = pv & xh
        if ph & high_bit:
            score += 1
        elif mh & high_bit:
            score -= 1
        ph = (ph << 1) | 1
        mh <<= 1
        pv = mh | ~(xv | ph)
        mv = ph & xv
    return score

def truth_from_jsonl(path):
    truth = {}
    source = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                obj = json.loads(line)
                truth[obj["row_key"]] = obj.get("reference", "")
                source[obj["row_key"]] = obj["dataset_id"]
    return truth, source

def truth_from_tsv(path):
    truth = {}
    source = {}
    with open(path, encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            truth[r["row_key"]] = r["reference_sequence"]
            source[r["row_key"]] = r.get("dataset_id", "")
    return truth, source

def main(argv=None):
    parser = argparse.ArgumentParser(description="Offline evaluator; never used by online reconstruction.")
    parser.add_argument("--pred", required=True)
    parser.add_argument("--truth")
    parser.add_argument("--truth-jsonl-cache")
    parser.add_argument("--output")
    args = parser.parse_args(argv)
    truth, source = truth_from_jsonl(args.truth_jsonl_cache) if args.truth_jsonl_cache else truth_from_tsv(args.truth)
    vals = []
    exact = []
    eds = []
    by_source = defaultdict(list)
    with open(args.pred, encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            ref = truth[r["row_key"]]
            dist = ed(r["reconstructed_sequence"], ref)
            acc = 1.0 - dist / len(ref)
            vals.append(acc)
            exact.append(1 if dist == 0 else 0)
            eds.append(dist)
            by_source[source.get(r["row_key"], "")].append(acc)
    rows = [{
        "rows": len(vals),
        "accuracy": f"{sum(vals)/len(vals):.15f}",
        "exact": f"{sum(exact)/len(exact):.15f}",
        "mean_edit_distance": f"{sum(eds)/len(eds):.15f}",
        "source_macro_accuracy": f"{sum(sum(v)/len(v) for v in by_source.values())/len(by_source):.15f}" if by_source else "",
    }]
    if args.output:
        with open(args.output, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, delimiter="\t", fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    else:
        for k, v in rows[0].items():
            print(f"{k}\t{v}")

if __name__ == "__main__":
    main()
