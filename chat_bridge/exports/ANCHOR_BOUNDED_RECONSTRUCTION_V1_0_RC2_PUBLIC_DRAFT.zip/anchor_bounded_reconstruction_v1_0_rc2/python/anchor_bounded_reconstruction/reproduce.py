import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

def load_recipe(path):
    # Minimal YAML subset for key: value lines.
    data = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            k, v = line.split(":", 1)
            data[k.strip()] = v.strip().strip('"')
    return data

def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--recipe", required=True)
    p.add_argument("--data-root", required=True)
    p.add_argument("--work-dir", required=True)
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--kernel", default="build/abr-kernel")
    args = p.parse_args(argv)
    recipe = load_recipe(args.recipe)
    work = Path(args.work_dir); work.mkdir(parents=True, exist_ok=True)
    payload = Path(args.data_root) / recipe["payload_cache"]
    out = work / "reconstruction.tsv"
    metric = work / "metrics.tsv"
    subprocess.check_call([sys.executable, "-m", "anchor_bounded_reconstruction.receiver", "--payload-cache-jsonl", str(payload), "--output", str(out), "--workers", str(args.workers), "--kernel", args.kernel])
    subprocess.check_call([sys.executable, "-m", "anchor_bounded_reconstruction.evaluate", "--pred", str(out), "--truth-jsonl-cache", str(payload), "--output", str(metric)])
    print(f"output={out}")
    print(f"metrics={metric}")

if __name__ == "__main__":
    main()
