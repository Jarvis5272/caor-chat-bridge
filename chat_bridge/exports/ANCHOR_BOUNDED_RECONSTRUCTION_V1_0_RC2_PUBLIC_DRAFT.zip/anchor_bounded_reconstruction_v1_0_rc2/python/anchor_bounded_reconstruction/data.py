import argparse
import csv
import hashlib
import json
from pathlib import Path

PREFIXES = (1, 2, 3, 5, 10, 20)

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def prepare_neutral(input_dir, dataset_id, out_dir):
    input_dir = Path(input_dir)
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    manifest = list(csv.DictReader(open(input_dir / "cluster_manifest.tsv", encoding="utf-8"), delimiter="\t"))
    reads = list(csv.DictReader(open(input_dir / "reads.tsv", encoding="utf-8"), delimiter="\t"))
    by_cluster = {}
    for r in reads:
        by_cluster.setdefault(str(r["cluster_id"]), []).append(r)
    online = out_dir / "online_manifest.tsv"
    truth = out_dir / "offline_truth.tsv"
    rows = 0; uses = 0
    with open(online, "w", encoding="utf-8", newline="") as of, open(truth, "w", encoding="utf-8", newline="") as tf:
        ow = csv.DictWriter(of, delimiter="\t", fieldnames=["ordinal","row_key","dataset_id","cluster_id","prefix_t","read_id","sequence"])
        tw = csv.DictWriter(tf, delimiter="\t", fieldnames=["row_key","dataset_id","reference_sequence"])
        ow.writeheader(); tw.writeheader()
        ordinal = 0
        for c in manifest:
            cid = str(c["cluster_id"])
            creads = by_cluster.get(cid, [])
            ref = c.get("reference", "")
            for t in PREFIXES:
                if len(creads) >= t:
                    row_key = f"{dataset_id}|{cid}|{t}"
                    tw.writerow({"row_key": row_key, "dataset_id": dataset_id, "reference_sequence": ref})
                    for r in creads[:t]:
                        ow.writerow({"ordinal": ordinal, "row_key": row_key, "dataset_id": dataset_id, "cluster_id": cid, "prefix_t": t, "read_id": r["read_id"], "sequence": r.get("read_sequence", r.get("sequence", ""))})
                    ordinal += 1; rows += 1; uses += t
    summary = [{"dataset_id": dataset_id, "clusters": len(manifest), "reads": len(reads), "prefix_rows": rows, "prefix_read_uses": uses, "online_manifest_sha256": sha256(online), "offline_truth_sha256": sha256(truth)}]
    with open(out_dir / "scope_summary.tsv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, delimiter="\t", fieldnames=list(summary[0])); w.writeheader(); w.writerows(summary)

def main(argv=None):
    p = argparse.ArgumentParser(prog="abr-data")
    sub = p.add_subparsers(dest="cmd", required=True)
    q = sub.add_parser("prepare")
    q.add_argument("--adapter", required=True, choices=["neutral_manifest_v1","oligo0_v1","ncomms19_365dishes_v1","binned_nanopore_v1","microsoft_cnr_processed_v1","dnaformer_binned_v1","trellisbma_datatoprocess_v1"])
    q.add_argument("--input", required=True)
    q.add_argument("--dataset-id", required=True)
    q.add_argument("--output", required=True)
    q.add_argument("--checkpoints", default="1,2,3,5,10,20")
    args = p.parse_args(argv)
    if args.cmd == "prepare":
        prepare_neutral(args.input, args.dataset_id, args.output)

if __name__ == "__main__":
    main()
