# PAPER V4.1 input blocker

- Expected ZIP: `paper_inputs/ACOR_INFOCOM_2027_OVERLEAF_V4_0.zip`
- ZIP exists: `False`
- Expected ZIP SHA-256: `be5cf548771039e40858ef81b1f60e58e053ac57fbd6d650510c055b60d54a6f`
- Observed ZIP SHA-256: `N/A`
- Expected `main.tex` SHA-256: `9c740ab6b74c9ac6acbb71c0dac60e585af24ebd158554adc8dfe0a33c5339b8`
- Observed `main.tex` SHA-256: `N/A`
- Status: `missing`

V4.0 source audit was intentionally stopped. No other paper source version was audited as V4.0.
