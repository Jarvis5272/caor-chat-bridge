# Evaluator edge-case rules

# Metric Definition Lock

- 正式 ED：每个 prefix row 的 unit-cost Levenshtein distance，aggregate 为逐 row 算术平均。
- 正式 Exact：`ED == 0`，aggregate 为逐 row exact rate。
- 正式 Accuracy：`1 - ED / max(1, reference_len)`，逐 prefix row 等权；不做 clamp，因此理论上允许小于 0。
- Macro accuracy：上述 row accuracy 的算术平均。
- Micro accuracy：`1 - sum(ED) / sum(reference_len)`，单独报告，不替代正式 macro accuracy。
- Clamped macro accuracy：`mean(max(0, 1-ED/reference_len))`，诊断口径，不替代正式值。
- Dataset macro accuracy：先对每个 dataset 的 row accuracy 聚合，再对 17 个 benchmark conditions 等权平均。
- 旧正式代码证据：`run_cecc_bounded.py` 在 offline Eval 中使用 `ed = levenshtein(out, refs[cid])`、`edit_accuracy = 1.0 - ed / max(1, len(reference))`、`exact_recovery = int(ed == 0)`。
- 本轮主实现：独立 Python Myers bit-vector Levenshtein；没有导入旧 evaluator。
- 双重检查：固定 seed `20260711` 抽取 1000 rows，用独立 naive DP 复核。

独立重算：Accuracy=0.966048954608200，Exact=0.348475661516820，Mean ED=4.280116902330771。旧逐行字段差异 rows=0。


补充锁定：missing/duplicate rows are scope blockers; reference is evaluator-only; formal Accuracy is row-macro and unclamped. Exact output normalization beyond evaluator input parsing should not be over-described unless directly quoted from `independent_evaluator.py`.
