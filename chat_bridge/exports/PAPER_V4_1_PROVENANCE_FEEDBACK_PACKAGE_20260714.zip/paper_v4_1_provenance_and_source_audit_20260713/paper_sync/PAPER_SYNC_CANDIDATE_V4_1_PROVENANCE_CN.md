# PAPER SYNC CANDIDATE: V4.1 Provenance and Source Audit

- Status: `READY_FOR_PAPER_SYNC_WITH_EXTERNAL_CITATIONS_PENDING`
- Source audit: `completed_against_hash-locked_V4.0_zip`
- Number/claim/method/deprecated audits: see `source_audit/`.
- Baseline provenance schema corrected: external upstream versions are not filled with ACOR project commit.
- External citations/licenses: `pending_external_verification`.
- Final handoff package: `results/paper_v4_1_provenance_and_source_audit_20260713/PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260714.zip`.
- Final handoff package SHA-256: recorded outside the zip in `PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260714.sha256`.
- Final handoff audit: `PAPER_V4_1_FINAL_HANDOFF_AUDIT_CN.md`.
- Required files missing: `0`; active pending status files: `0`; active final-label conflicts: `0`.
- Number/Claim/Deprecated/Method counts: `235/235/0`, `19/0`, `0 active risk`, `20/0/0`.
- The old `PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260713.zip` is `deprecated_pending_handoff_package`.
- Algorithm modified: `No`
- New experiment run: `No`
