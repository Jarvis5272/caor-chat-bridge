# PAPER SYNC CANDIDATE: V4.1 Provenance and Source Audit

- Status: `READY_FOR_PAPER_SYNC_WITH_EXTERNAL_CITATIONS_PENDING`
- Source audit: `completed_against_hash-locked_V4.0_zip`
- Number/claim/method/deprecated audits: see `source_audit/`.
- Baseline provenance schema corrected: external upstream versions are not filled with ACOR project commit.
- External citations/licenses: `pending_external_verification`.
- Algorithm modified: `No`
- New experiment run: `No`
