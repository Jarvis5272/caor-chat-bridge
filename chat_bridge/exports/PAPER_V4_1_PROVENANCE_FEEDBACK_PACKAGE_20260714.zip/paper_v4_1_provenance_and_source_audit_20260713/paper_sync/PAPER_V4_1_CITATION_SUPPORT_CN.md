# V4.1 citation support

- Citation needs mapped: 15
- Local metadata candidate files scanned/listed: 15
- External verification required rows: 15

No DOI, author, or publication year was invented. Rows marked `external_verification_required` need manual bibliography verification before paper submission.
