# V4.1 reproducibility inserts

- 数据、row key、prefix payload、runner、kernel、serializer 和 evaluator 均使用本地锁文件追溯。
- CAPPED_17 使用 17 benchmark conditions、82,462 prefix rows、428,322 prefix-read uses。
- Online reconstruction payload excludes reference sequence; reference is used only by evaluator.
- Runtime tables must name protocol and boundary; do not mix P0, full-source V1/V2/V3, and baseline batch protocols silently.
- External reference metadata marked `external_verification_required` must be filled by verified bibliography work, not inferred locally.
