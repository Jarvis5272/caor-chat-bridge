# V4.1 provenance blockers

- V4.0 source audit status: `complete`.
- Dataset primary publication metadata and licenses are not fully locally verified for all sources.
- Baseline primary references and licenses require external verification.
- Storage/filesystem details were not recorded in the P0 environment lock.

These remaining blockers do not change locked experimental numbers or V4.0 source consistency. They constrain citation/provenance wording and final submission readiness until external references and licenses are verified.
