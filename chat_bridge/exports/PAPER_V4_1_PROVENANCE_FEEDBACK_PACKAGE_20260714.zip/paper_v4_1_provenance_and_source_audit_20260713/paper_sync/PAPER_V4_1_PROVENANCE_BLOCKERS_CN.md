# V4.1 provenance blockers

- V4.0 source audit status: `pending_input_missing`.
- Dataset primary publication metadata and licenses are not fully locally verified for all sources.
- Baseline primary references and licenses require external verification.
- Storage/filesystem details were not recorded in the P0 environment lock.

These blockers do not change locked experimental numbers. They constrain citation/provenance wording and final paper source acceptance.
