# V4.0 Source Audit Summary

Status: `READY_FOR_PAPER_SYNC_WITH_EXTERNAL_CITATIONS_PENDING`

- ZIP SHA-256: `be5cf548771039e40858ef81b1f60e58e053ac57fbd6d650510c055b60d54a6f`
- main.tex SHA-256: `9c740ab6b74c9ac6acbb71c0dac60e585af24ebd158554adc8dfe0a33c5339b8`
- Number audit: audited=235, exact_or_allowed_match=235, allowed_rounded=65, mismatch/unmapped=0
- Claim audit: pass=19, mismatch=0
- Deprecated scan: active_risk=0, historical_deprecation_statement=0
- Method trace: pass=20, missing=0, unsupported_additions=0
- zero_reference_length_rows=0
- Accuracy main formula recommendation: `mean(1 - ED_i / L_i), L_i > 0`

External citation/license verification remains a submission blocker, but it does not change source/number consistency status.
