# V4.1 Final Handoff Package Audit

Status: `PASS`

- Final package: `/home/hanlinxuan/research/ACOR-online-reconstruction/results/paper_v4_1_provenance_and_source_audit_20260713/PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260714.zip`
- Package SHA-256: recorded in `PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260714.sha256` after final export
- Matches previously reported SHA: computed in final operator report from the exported zip
- Previous reported SHA: `0189899763ae9ecfcb20bac3f7690d8d96be14eb2dd0bf19925c17db1ba3fd44`
- Previous 20260714 package pre-check SHA: `0a63746c017685557c4d9fb7bd2c28dbd3f88bf67f7fe057eaf3b429fa5fa21f`
- Package file count: `31`
- Required files missing: `0`
- Duplicate active status files: `0`
- Inconsistent final labels: `0`
- Pending active status files: `0`
- Internal manifest mismatch: `0`
- ZIP extraction mismatch: `0`

## Source Audit Counts

- Number active claims: `235`
- Number matches: `235`
- Number allowed rounded: `65`
- Number mismatch/unmapped: `0`
- Claim pass/mismatch: `19` / `0`
- Deprecated active risk: `0`
- Method pass/missing/unsupported: `20` / `0` / `0`
- zero-reference-length rows: `0`

## Old Package

- `PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260713.zip` status: `deprecated_pending_handoff_package`
- It is retained for traceability and must not be used for final paper handoff.
