# V4.1 Final Handoff Package Audit

Status: `FAIL`

- Final package: `/home/hanlinxuan/research/ACOR-online-reconstruction/results/paper_v4_1_provenance_and_source_audit_20260713/PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260714.zip`
- Package SHA-256: `d327d73dd6b21544200958899ac5fdec216fa040a8d2540cd43bfdd4584b71af`
- Matches previously reported SHA: `false`
- Previous reported SHA: `0189899763ae9ecfcb20bac3f7690d8d96be14eb2dd0bf19925c17db1ba3fd44`
- Previous 20260714 package pre-check SHA: `0015eb1cbca38e6513612e14774919464f14e359358b654bac7532ced5517a1d`
- Package file count: `35`
- Required files missing: `0`
- Duplicate active status files: `0`
- Inconsistent final labels: `0`
- Pending active status files: `0`
- Internal manifest mismatch: `0`
- ZIP extraction mismatch: `1`

## Source Audit Counts

- Number active claims: `235`
- Number matches: `235`
- Number allowed rounded: `65`
- Number mismatch/unmapped: `0`
- Claim pass/mismatch: `19` / `0`
- Deprecated active risk: `0`
- Method pass/missing/unsupported: `20` / `0` / `0`
- zero-reference-length rows: `0`

## Old Package

- `PAPER_V4_1_PROVENANCE_FEEDBACK_PACKAGE_20260713.zip` status: `deprecated_pending_handoff_package`
- It is retained for traceability and must not be used for final paper handoff.
