# DNAformer public metadata review

Source: Zenodo record 13896773, DOI 10.5281/zenodo.13896773.

The record lists five datasets: two Illumina datasets and three Nanopore datasets, with raw reads and processed binned reads. License is CC BY 4.0. This audit downloaded only BinnedNanoporeTwoFlowcells.txt and BinnedTestIllumina.txt. Raw signal archives were not downloaded.

Official code source checked: itaiorr/Deep-DNA-based-storage v1.0 GitHub release metadata saved locally.

Format note: the record text describes an 18-star separator, while the downloaded binned files use a 29-star all-star separator. The parser therefore treats a nonempty all-star line as the separator predicate; no malformed cluster remains under that source-grounded predicate.
