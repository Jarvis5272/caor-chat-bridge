# OPTION F5 DNAformer Nanopore

F4 + DNAformer Nanopore Two Flowcells full。

规模：clusters=133464, reads=3072383, prefix_rows=739143, prefix_read_uses=4298829。

定位：新增一个公开、CC BY 4.0、与 F4 独立的 DNAformer publication family；First/Second/Combined 不重复计数。

正式运行：supplement-only 可只跑 DNAformer Nanopore；combined-F5 主表必须在 combined row keys 上重跑四方法。
