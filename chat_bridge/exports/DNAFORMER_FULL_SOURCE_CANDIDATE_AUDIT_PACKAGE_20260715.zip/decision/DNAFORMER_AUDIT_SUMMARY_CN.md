# DNAformer Full-Source Candidate Audit

final_label: DNAFORMER_NANOPORE_AND_ILLUMINA_CANDIDATES_READY

## Download/Hash
P1/P2 binned files downloaded and MD5-verified against Zenodo.

## Scope
- DNF_NANOPORE_TWO_FLOWCELLS_FULL: clusters=109976, reads=2354584, prefix_rows=609095, prefix_read_uses=3535078
- DNF_TEST_ILLUMINA_FULL: clusters=109944, reads=3183840, prefix_rows=643225, prefix_read_uses=4186823

## Recommendation
DNAformer Nanopore Two Flowcells is recommended as an F5 main-source candidate if user approves a new experiment. DNAformer Test Illumina is recommended as a cross-technology supplement candidate; F6 requires explicit approval.

No reconstruction experiment was started.
