# DNAformer Execution Options

本阶段未启动任何 reconstruction 实验。

supplement-only：只对新增 DNAformer 数据运行 Current/BBS/VS/BMALA，可保留 F4 已锁定结果不重跑。

combined-F5：若要形成新的 combined runtime/quality 主表，必须在 F4+DNAformer Nanopore combined row keys 上重跑 Current/BBS/VS/BMALA，不能把 F4 runtime 与 supplement runtime 拼接成正式 combined runtime。
