# OPTION F5 + Illumina Supplement

F5 + DNAformer Test Illumina supplement。

诊断性总规模：clusters=243408, reads=6256223, prefix_rows=1382368, prefix_read_uses=8485652。

定位：Illumina 与 Nanopore 同属 DNAformer publication family，但代表不同 sequencing technology condition；推荐作为 cross-technology supplement，是否形成 F6 需另行批准。
