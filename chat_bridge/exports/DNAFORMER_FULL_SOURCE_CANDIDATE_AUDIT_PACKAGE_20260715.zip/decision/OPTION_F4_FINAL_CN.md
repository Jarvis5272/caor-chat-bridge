# OPTION F4 FINAL

保留当前 F4：clusters=23488, reads=717799, prefix_rows=130048, prefix_read_uses=763751。

优点：已完成并锁定。风险：不包含 DNAformer 新公开来源。
