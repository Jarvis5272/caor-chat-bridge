# PAPER_SYNC_CANDIDATE_OVERNIGHT_F4_AND_TRELLISBMA

status: OVERNIGHT_F4_LOCKED_TRELLISBMA_QUALITY_LOCKED_RUNTIME_PARTIAL

- F4 results are locked and usable as the public full-source main benchmark candidate.
- TrellisBMA DataToProcess is locked for quality but runtime is partial because BBS CV exceeded 10%; use as simulated/algorithmic supplemental evidence only.
- Do not merge TrellisBMA into the F4 four-source aggregate.
- Do not reuse CAPPED_17 runtime or speedup values.
