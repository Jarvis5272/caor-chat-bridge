# Morning Summary - F4 + TrellisBMA

- final_label: OVERNIGHT_F4_LOCKED_TRELLISBMA_QUALITY_LOCKED_RUNTIME_PARTIAL
- F4 final label: PUBLIC_FULL_F4_V1_ALL_CORE_METHODS_LOCKED
- TrellisBMA final status: quality locked; runtime partial because BBS wall-clock CV > 10%
- No NBT17/CPL/MUSCLE/Clover/uploaded/Space Shuttle/Vitruvian/Apollo/parameter/ablation/new algorithm runs were started in this chain.
- Algorithm modified: No
- Baseline source modified: No
- Paper modified: No

## F4 Main Table
|Method|Accuracy|Exact|Mean ED|Dataset-macro Accuracy|Median runtime|Runtime CV|Prefix/s|Speed relation vs Current w1|Runtime status|Determinism|
|---|---|---|---|---|---|---|---|---|---|---|
|Current Method|0.963371172619247|0.182255782480315|4.478407972440944|0.953504652554887|155.416619|0.003948|836.770231|1.000x|locked|locked|
|BBS|0.954851451636634|0.092042937992126|5.543130228838582|0.943229777318358|876.176906|0.001849|148.426647|5.637601x runtime vs Current w1|locked|locked|
|VS|0.936537116505805|0.116887610728346|7.762510765255906|0.920865644248350|107.771225|0.005437|1206.704298|0.693434x runtime vs Current w1|locked|locked|
|BMALA|0.946955026987277|0.300965797244095|6.561631090059056|0.930577131278821|183.389169|0.009644|709.136754|1.179984x runtime vs Current w1|locked|locked|

## F4 Worker Scaling
|config|workers|median_runtime|speedup_vs_w1|parallel_efficiency|prefix_per_second|prefix_read_uses_per_second|
|---|---|---|---|---|---|---|
|current_w1|1|155.4166187942028|1.0|1.0|836.7702309378186|4914.2170633073165|
|current_w8|8|23.82623567432165|6.522919563063863|0.8153649453829829|5458.184909173763|32055.04261938954|
|current_w16|16|16.10978077352047|9.647345359885962|0.6029590849928727|8072.61140472867|47409.149183170266|

## TrellisBMA Supplement Main Table
|Method|Accuracy|Exact|Mean ED|Dataset-macro Accuracy|Median runtime|Runtime CV|Prefix/s|Speed relation vs Current w1|Runtime status|Determinism|
|---|---|---|---|---|---|---|---|---|---|---|
|Current Method|0.954434731144154|0.009439848094398|5.012179574121796|0.954434731144154|22.014599|0.010098|1674.570593|1.000x|locked|locked|
|BBS|0.945379085853684|0.005208192052082|6.008300556083006|0.945379085853684|495.972652|0.154343|74.328695|22.529261x runtime vs Current w1|environment_blocked|locked|
|VS|0.931500930914793|0.003010986030110|7.534897599348976|0.931500930914793|16.155817|0.019558|2281.840619|0.733868x runtime vs Current w1|locked|locked|
|BMALA|0.959858698198512|0.385948731859487|4.415543198155432|0.959858698198512|31.226579|0.015794|1180.564784|1.418449x runtime vs Current w1|locked|locked|

## TrellisBMA Runtime Summary
|config|method|runs|completed_runs|median|min|max|cv|runtime_status|
|---|---|---|---|---|---|---|---|---|
|bbs|BBS|3|3|495.9726515375078|492.10790552943945|638.9895671233535|0.15434273497362466|environment_blocked|
|bmala|BMALA|3|3|31.226579435169697|30.63070621713996|31.60690640285611|0.015793754990383966|locked|
|current_w1|Current Method w1|3|3|22.014598943293095|21.801147013902664|22.24576636403799|0.010098246970272343|locked|
|current_w16|Current Method w16|3|3|2.810225371271372|2.7423526905477047|2.8177910186350346|0.014889276013106304|locked|
|current_w8|Current Method w8|3|3|3.780317611992359|3.742739651352167|4.044977478682995|0.04271883997853748|locked|
|vs|VS|3|3|16.155817236751318|15.995722871273756|16.608625929802656|0.019558250127248846|locked|

## Checks
- TrellisBMA smoke completed methods: 6/6
- TrellisBMA formal runs completed: 18/18
- F4 DP double check: 4000 rows, mismatches=0
- TrellisBMA DP double check: 4000 rows, mismatches=0
- Active service: caor-f4-overnight-chain.service inactive/dead after completion

## Key Paths
- F4 package: /home/hanlinxuan/research/ACOR-online-reconstruction/results/public_full_f4_formal_20260714/PUBLIC_FULL_F4_FORMAL_FEEDBACK_PACKAGE_20260714.zip
- TrellisBMA tables: /home/hanlinxuan/research/ACOR-online-reconstruction/results/public_full_trellisbma_supplement_20260714/tables/TRELLISBMA_FULL_SUPPLEMENT_MAIN_TABLE.tsv
- Overnight status: /home/hanlinxuan/research/ACOR-online-reconstruction/results/overnight_f4_then_trellisbma_20260714/morning/OVERNIGHT_FINAL_STATUS.tsv
