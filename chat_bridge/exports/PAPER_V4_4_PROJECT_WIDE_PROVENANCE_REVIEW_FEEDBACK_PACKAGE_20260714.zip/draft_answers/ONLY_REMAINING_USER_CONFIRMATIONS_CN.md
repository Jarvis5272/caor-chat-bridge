# 最少用户确认问题

## R01 Clover closes CR01,CR02

- Clover 原始目录最初从哪里获得？
- 是否允许科研使用？
- clover 与 clover_clusters 是否确实同一来源的两个处理视图？

## R02 NBT17 variants closes CR03,CR04,CR05

- 是否确认该 NBT17 id20 数据可用于本文科研实验？
- 是否不计划重新分发原始数据，只报告结果/metadata？

## R03 NComms19 Space Shuttle variants closes CR06,CR07,CR08

- 是否确认 Space Shuttle variants 可用于本文科研实验？
- 是否不计划重新分发原始 FASTQ/processed data？

## R04 NComms19 Vitruvian variant closes CR09

- 是否确认 Vitruvian variant 可用于本文科研实验？
- 是否不计划重新分发原始 FASTQ/processed data？

## R05 TrellisBMA DataToProcess simulation closes CR10

- DataToProcess 原始文件是否来自 TReconLM official dataset/repo？
- 是否允许科研使用？

## R06 uploaded_* conditions closes CR11,CR12,CR13

- uploaded 数据最初由谁/从哪里提供？
- 是否允许科研使用？
- compact 与 real_clusters 是否确认为同一上传 family 的处理视图？
