# Codex 拟定 Provenance 答案

## 【R01 Clover】

Codex拟定答案：

Codex 能恢复到本地 Clover clean IDS pack：两行都来自 `data/clover_clusters/reads` 与 `data/clover_clusters/truth`，被转换为 `clover` / `clover_clusters` 两个 BBS-template 条件，簇数和读数均为 5000 / 1,000,000，IDS rate 极低。项目记录明确把 Clover 标为 source-gap exploratory，不能作为 paper main independent source。最可能答案是：本地已有可解析的 Clover artifact，`clover_clusters` 与 `clover` 是同一 Clover 本地 artifact 的格式/处理别名，而不是两个已独立验证的公开来源。

主要证据：
- E002: CAPPED_17 is benchmark conditions, not 17 independent sources; Clover/Uploaded are source-gap exploratory. (`chat_bridge/current_project_source_latest/06_DATASETS_SOURCES_AND_SCALE_PLAN_CN.md`)
- E003: Final source-audited clean IDS ledger classifies BBS trio, NBT17, NComms19, TrellisBMA, Clover and uploaded rows. (`results/final_source_audited_clean_ids_review_20260627/final_source_audited_17_candidate_ledger.tsv`)
- E004: Report states NBT17/NComms/TrellisBMA are local projections/conversions; Clover/uploaded remain source gaps. (`results/final_source_audited_clean_ids_review_20260627/FINAL_SOURCE_AUDITED_CLEAN_IDS_REVIEW_REPORT_CN.md`)
- E009: Per-condition source manifests record raw paths and source status for the 13 rows. (`data/bbs_template_clean_ids_production_20260627/*/source/source_paths_manifest.tsv`)
- E010: Per-condition production README records input kind, source family, semantic status, clusters/reads and IDS rates. (`data/bbs_template_clean_ids_production_20260627/*/README.md`)

置信度：medium

可以自动填入的字段：

source_type=local artifact/source-gap; original_archive_or_directory=data/clover_clusters; generation/preprocessing=converted to BBS-template clean IDS; redistribution=blocked until source/license confirmed

仍需用户确认：
- Clover 原始目录最初从哪里获得？
- 是否允许科研使用？
- clover 与 clover_clusters 是否确实同一来源的两个处理视图？

## 【R02 NBT17 variants】

Codex拟定答案：

Codex 拟定答案：三条 NBT17 row 都属于同一 `data-nbt17` / id20 family 的本地 projected IDS variants。项目内本地 git remote 指向 `https://github.com/uwmisl/data-nbt17.git`，本地文件包含 `id20.fastq.gz` 与 `id20.refs.txt.gz`，既有 source audit 将 top500/top5000/k15 明确标为 local subset/projection，而非官方论文直接报告的完整 benchmark。因此可填为公开基础数据 + 本地派生脚本/投影条件。

主要证据：
- E003: Final source-audited clean IDS ledger classifies BBS trio, NBT17, NComms19, TrellisBMA, Clover and uploaded rows. (`results/final_source_audited_clean_ids_review_20260627/final_source_audited_17_candidate_ledger.tsv`)
- E004: Report states NBT17/NComms/TrellisBMA are local projections/conversions; Clover/uploaded remain source gaps. (`results/final_source_audited_clean_ids_review_20260627/FINAL_SOURCE_AUDITED_CLEAN_IDS_REVIEW_REPORT_CN.md`)
- E005: Local data-nbt17 repo remote is https://github.com/uwmisl/data-nbt17.git. (`data/third_generation_nanopore/data-nbt17/.git remote`)
- E011: NBT17 source audit names this converter as the route for id20/topN/k15 local projected variants. (`scripts/prepare_nbt17_random_access.py`)
- E017: Public candidate from local git remote for NBT17 source context. (`https://github.com/uwmisl/data-nbt17`)

置信度：high

可以自动填入的字段：

source_type=public base data plus local derivation; original_source_name=data-nbt17 id20; repository=https://github.com/uwmisl/data-nbt17; generation=top500/top5000/k15 local projected IDS variants

仍需用户确认：
- 是否确认该 NBT17 id20 数据可用于本文科研实验？
- 是否不计划重新分发原始数据，只报告结果/metadata？

## 【R03 NComms19 Space Shuttle variants】

Codex拟定答案：

Codex 拟定答案：三条 Space Shuttle row 来自同一 NComms19 nanopore public/local source family，公开基础仓库由本地 git remote 指向 `https://github.com/uwmisl/data-ncomms19-nanopore.git`。本地 readme 明确 `space_shuttle` 对应 `seqs_space_shuttle.txt` 和 sequencing run 13。三条 row 是同一 Space Shuttle 基础数据上的 k15/min5/windowed 本地 curated/projection variants，而非三个独立公开数据集。

主要证据：
- E003: Final source-audited clean IDS ledger classifies BBS trio, NBT17, NComms19, TrellisBMA, Clover and uploaded rows. (`results/final_source_audited_clean_ids_review_20260627/final_source_audited_17_candidate_ledger.tsv`)
- E004: Report states NBT17/NComms/TrellisBMA are local projections/conversions; Clover/uploaded remain source gaps. (`results/final_source_audited_clean_ids_review_20260627/FINAL_SOURCE_AUDITED_CLEAN_IDS_REVIEW_REPORT_CN.md`)
- E006: Local NComms19 nanopore repo remote is https://github.com/uwmisl/data-ncomms19-nanopore.git. (`data/third_generation_nanopore/data-ncomms19-nanopore/.git remote`)
- E007: Readme maps space_shuttle to seqs_space_shuttle.txt/run13 and vitruvian to seqs_Vitruvian.txt/run20. (`data/third_generation_nanopore/data-ncomms19-nanopore/read_me_data-ncomms19-nanopore.txt`)
- E012: NComms source audit names this converter for Space Shuttle / Vitruvian local curated projections. (`scripts/prepare_ncomms19_nanopore.py`)

置信度：high

可以自动填入的字段：

source_type=public base data plus local derivation; original_source_name=NComms19 Space Shuttle; repository=https://github.com/uwmisl/data-ncomms19-nanopore; source files=seqs_space_shuttle.txt + nanopore_run13.fastq.gz; generation=k15/min5/windowed local projections

仍需用户确认：
- 是否确认 Space Shuttle variants 可用于本文科研实验？
- 是否不计划重新分发原始 FASTQ/processed data？

## 【R04 NComms19 Vitruvian variant】

Codex拟定答案：

Codex 拟定答案：Vitruvian row 属于 NComms19 nanopore public/local source family。本地 readme 明确 `vitruvian` 对应 `seqs_Vitruvian.txt` 和 sequencing run 20。该 row 是 Vitruvian 基础数据上的 min5/windowed 本地 curated/projection variant，不能和 Space Shuttle 强行合并为同一 source row；它共享 NComms19 仓库来源，但 reference/read set 是 Vitruvian 自己的文件。

主要证据：
- E003: Final source-audited clean IDS ledger classifies BBS trio, NBT17, NComms19, TrellisBMA, Clover and uploaded rows. (`results/final_source_audited_clean_ids_review_20260627/final_source_audited_17_candidate_ledger.tsv`)
- E004: Report states NBT17/NComms/TrellisBMA are local projections/conversions; Clover/uploaded remain source gaps. (`results/final_source_audited_clean_ids_review_20260627/FINAL_SOURCE_AUDITED_CLEAN_IDS_REVIEW_REPORT_CN.md`)
- E006: Local NComms19 nanopore repo remote is https://github.com/uwmisl/data-ncomms19-nanopore.git. (`data/third_generation_nanopore/data-ncomms19-nanopore/.git remote`)
- E007: Readme maps space_shuttle to seqs_space_shuttle.txt/run13 and vitruvian to seqs_Vitruvian.txt/run20. (`data/third_generation_nanopore/data-ncomms19-nanopore/read_me_data-ncomms19-nanopore.txt`)
- E012: NComms source audit names this converter for Space Shuttle / Vitruvian local curated projections. (`scripts/prepare_ncomms19_nanopore.py`)

置信度：high

可以自动填入的字段：

source_type=public base data plus local derivation; original_source_name=NComms19 Vitruvian; repository=https://github.com/uwmisl/data-ncomms19-nanopore; source files=seqs_Vitruvian.txt + nanopore_run20.fastq.gz; generation=min5/windowed local projection

仍需用户确认：
- 是否确认 Vitruvian variant 可用于本文科研实验？
- 是否不计划重新分发原始 FASTQ/processed data？

## 【R05 TrellisBMA DataToProcess simulation】

Codex拟定答案：

Codex 拟定答案：该 row 是 TReconLM / TrellisBMA 相关 DataToProcess 的本地 clean IDS conversion，项目记录和 source audit 指向 `scripts/build_external_dataset_batch35_trellisbma_datatoprocess_full.py`，本地 converted source 为 `data/converted_external/trellisbma_datatoprocess_sim/Clusters.txt` 与 `Centers.txt`。TReconLM 本地教程还引用了 `tracereconstruction2026/TReconLM_datasets`，但 DataToProcess 与公开数据仓库的内容连续性尚未完全闭合。因此这是 partial-source-confirmed local conversion，而不是已完全验证 public release continuity。

主要证据：
- E003: Final source-audited clean IDS ledger classifies BBS trio, NBT17, NComms19, TrellisBMA, Clover and uploaded rows. (`results/final_source_audited_clean_ids_review_20260627/final_source_audited_17_candidate_ledger.tsv`)
- E004: Report states NBT17/NComms/TrellisBMA are local projections/conversions; Clover/uploaded remain source gaps. (`results/final_source_audited_clean_ids_review_20260627/FINAL_SOURCE_AUDITED_CLEAN_IDS_REVIEW_REPORT_CN.md`)
- E013: Source audit names this script as local conversion evidence for DataToProcess. (`scripts/build_external_dataset_batch35_trellisbma_datatoprocess_full.py`)
- E020: TReconLM local tutorial refers to this dataset repo; DataToProcess row remains local conversion/source-metadata caveat. (`https://huggingface.co/tracereconstruction2026/TReconLM_datasets`)

置信度：medium

可以自动填入的字段：

source_type=local conversion from TReconLM/TrellisBMA-related data; generation=DataToProcess full conversion; redistribution=blocked until source/license confirmed

仍需用户确认：
- DataToProcess 原始文件是否来自 TReconLM official dataset/repo？
- 是否允许科研使用？

## 【R06 uploaded_* conditions】

Codex拟定答案：

Codex 能恢复到本地 uploaded artifact：`uploaded_real_clusters` 使用 `data/uploaded_real_clusters/reads` 与 `truth`，compact 两行使用 `data/uploaded_real_clusters_compact/reads` 与 `truth`，转换脚本为 `scripts/convert_uploaded_clusters.py`。项目记录把 uploaded variants 明确归为 source-gap/user-upload artifacts，likely duplicate/derived，不能作为独立 paper dataset。最可能答案是：三条 uploaded row 是同一 uploaded/real-clusters family 的原始和 compact 处理视图，但上传者/原始来源/科研授权仍需要用户确认。

主要证据：
- E002: CAPPED_17 is benchmark conditions, not 17 independent sources; Clover/Uploaded are source-gap exploratory. (`chat_bridge/current_project_source_latest/06_DATASETS_SOURCES_AND_SCALE_PLAN_CN.md`)
- E003: Final source-audited clean IDS ledger classifies BBS trio, NBT17, NComms19, TrellisBMA, Clover and uploaded rows. (`results/final_source_audited_clean_ids_review_20260627/final_source_audited_17_candidate_ledger.tsv`)
- E004: Report states NBT17/NComms/TrellisBMA are local projections/conversions; Clover/uploaded remain source gaps. (`results/final_source_audited_clean_ids_review_20260627/FINAL_SOURCE_AUDITED_CLEAN_IDS_REVIEW_REPORT_CN.md`)
- E009: Per-condition source manifests record raw paths and source status for the 13 rows. (`data/bbs_template_clean_ids_production_20260627/*/source/source_paths_manifest.tsv`)
- E010: Per-condition production README records input kind, source family, semantic status, clusters/reads and IDS rates. (`data/bbs_template_clean_ids_production_20260627/*/README.md`)

置信度：medium

可以自动填入的字段：

source_type=local uploaded artifact/source-gap; original_archive_or_directory=data/uploaded_real_clusters*; generation=convert_uploaded_clusters.py; redistribution=blocked until source/provider confirmed

仍需用户确认：
- uploaded 数据最初由谁/从哪里提供？
- 是否允许科研使用？
- compact 与 real_clusters 是否确认为同一上传 family 的处理视图？
