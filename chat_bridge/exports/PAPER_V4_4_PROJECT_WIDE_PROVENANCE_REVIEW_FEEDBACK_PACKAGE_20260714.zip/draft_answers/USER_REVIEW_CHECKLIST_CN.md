# 用户审查 Checklist

## R01 Clover

请选择：正确 / 基本正确，需要以下修正 / 错误 / 无法判断

补充说明：

## R02 NBT17 variants

请选择：正确 / 基本正确，需要以下修正 / 错误 / 无法判断

补充说明：

## R03 NComms19 Space Shuttle variants

请选择：正确 / 基本正确，需要以下修正 / 错误 / 无法判断

补充说明：

## R04 NComms19 Vitruvian variant

请选择：正确 / 基本正确，需要以下修正 / 错误 / 无法判断

补充说明：

## R05 TrellisBMA DataToProcess simulation

请选择：正确 / 基本正确，需要以下修正 / 错误 / 无法判断

补充说明：

## R06 uploaded_* conditions

请选择：正确 / 基本正确，需要以下修正 / 错误 / 无法判断

补充说明：
