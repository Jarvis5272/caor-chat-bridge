# Provenance contradictions and risks

- C001 Clover: Do not promote to paper-ready source without author confirmation.
- C002 NComms variants: Must word as local projections from public base data, not official benchmark rows.
- C003 TrellisBMA DataToProcess: Keep source metadata caveat.
- C004 uploaded_*: Cannot close without user confirmation.
