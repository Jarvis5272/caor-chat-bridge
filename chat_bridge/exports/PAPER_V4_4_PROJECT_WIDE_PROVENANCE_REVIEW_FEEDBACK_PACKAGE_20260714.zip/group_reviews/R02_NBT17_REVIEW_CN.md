# R02 NBT17 variants Provenance Review

## Conditions

nbt17_id20_m2m_top500, nbt17_id20_m2m_top5000, nbt17_id20_m2m_top500_k15

## Codex 拟定来源

Codex 拟定答案：三条 NBT17 row 都属于同一 `data-nbt17` / id20 family 的本地 projected IDS variants。项目内本地 git remote 指向 `https://github.com/uwmisl/data-nbt17.git`，本地文件包含 `id20.fastq.gz` 与 `id20.refs.txt.gz`，既有 source audit 将 top500/top5000/k15 明确标为 local subset/projection，而非官方论文直接报告的完整 benchmark。因此可填为公开基础数据 + 本地派生脚本/投影条件。

## 证据等级

- evidence_level: verified_local_file + verified_project_record
- confidence: high
- evidence_ids: E003, E004, E005, E011, E017

## 是否公开 release / 本地派生

- 公开 release 连续性只在本地证据支持处陈述；缺少内容连续性处不自动 closure。
- 本地派生/投影/转换不等于官方 paper benchmark。

## 剩余最少人工确认

- 是否确认该 NBT17 id20 数据可用于本文科研实验？
- 是否不计划重新分发原始数据，只报告结果/metadata？
