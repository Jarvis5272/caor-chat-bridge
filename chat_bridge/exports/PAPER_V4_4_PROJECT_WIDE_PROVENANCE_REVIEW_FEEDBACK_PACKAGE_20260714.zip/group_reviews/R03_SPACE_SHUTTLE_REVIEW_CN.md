# R03 NComms19 Space Shuttle variants Provenance Review

## Conditions

ncomms19_space_shuttle_k15_min5, ncomms19_space_shuttle_min5, ncomms19_space_shuttle_min5_windowed

## Codex 拟定来源

Codex 拟定答案：三条 Space Shuttle row 来自同一 NComms19 nanopore public/local source family，公开基础仓库由本地 git remote 指向 `https://github.com/uwmisl/data-ncomms19-nanopore.git`。本地 readme 明确 `space_shuttle` 对应 `seqs_space_shuttle.txt` 和 sequencing run 13。三条 row 是同一 Space Shuttle 基础数据上的 k15/min5/windowed 本地 curated/projection variants，而非三个独立公开数据集。

## 证据等级

- evidence_level: verified_local_file + verified_project_record
- confidence: high
- evidence_ids: E003, E004, E006, E007, E012, E018

## 是否公开 release / 本地派生

- 公开 release 连续性只在本地证据支持处陈述；缺少内容连续性处不自动 closure。
- 本地派生/投影/转换不等于官方 paper benchmark。

## 剩余最少人工确认

- 是否确认 Space Shuttle variants 可用于本文科研实验？
- 是否不计划重新分发原始 FASTQ/processed data？
