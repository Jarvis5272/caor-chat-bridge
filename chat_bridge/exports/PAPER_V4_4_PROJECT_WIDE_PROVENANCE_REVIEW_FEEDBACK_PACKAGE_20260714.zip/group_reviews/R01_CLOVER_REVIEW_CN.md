# R01 Clover Provenance Review

## Conditions

clover, clover_clusters

## Codex 拟定来源

Codex 能恢复到本地 Clover clean IDS pack：两行都来自 `data/clover_clusters/reads` 与 `data/clover_clusters/truth`，被转换为 `clover` / `clover_clusters` 两个 BBS-template 条件，簇数和读数均为 5000 / 1,000,000，IDS rate 极低。项目记录明确把 Clover 标为 source-gap exploratory，不能作为 paper main independent source。最可能答案是：本地已有可解析的 Clover artifact，`clover_clusters` 与 `clover` 是同一 Clover 本地 artifact 的格式/处理别名，而不是两个已独立验证的公开来源。

## 证据等级

- evidence_level: verified_local_file + verified_project_record
- confidence: medium
- evidence_ids: E002, E003, E004, E009, E010, E015

## 是否公开 release / 本地派生

- 公开 release 连续性只在本地证据支持处陈述；缺少内容连续性处不自动 closure。
- 本地派生/投影/转换不等于官方 paper benchmark。

## 剩余最少人工确认

- Clover 原始目录最初从哪里获得？
- 是否允许科研使用？
- clover 与 clover_clusters 是否确实同一来源的两个处理视图？
