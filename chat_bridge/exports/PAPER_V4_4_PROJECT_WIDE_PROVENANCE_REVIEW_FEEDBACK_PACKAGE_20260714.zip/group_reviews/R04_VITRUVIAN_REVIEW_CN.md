# R04 NComms19 Vitruvian variant Provenance Review

## Conditions

ncomms19_vitruvian_min5_windowed

## Codex 拟定来源

Codex 拟定答案：Vitruvian row 属于 NComms19 nanopore public/local source family。本地 readme 明确 `vitruvian` 对应 `seqs_Vitruvian.txt` 和 sequencing run 20。该 row 是 Vitruvian 基础数据上的 min5/windowed 本地 curated/projection variant，不能和 Space Shuttle 强行合并为同一 source row；它共享 NComms19 仓库来源，但 reference/read set 是 Vitruvian 自己的文件。

## 证据等级

- evidence_level: verified_local_file + verified_project_record
- confidence: high
- evidence_ids: E003, E004, E006, E007, E012, E018

## 是否公开 release / 本地派生

- 公开 release 连续性只在本地证据支持处陈述；缺少内容连续性处不自动 closure。
- 本地派生/投影/转换不等于官方 paper benchmark。

## 剩余最少人工确认

- 是否确认 Vitruvian variant 可用于本文科研实验？
- 是否不计划重新分发原始 FASTQ/processed data？
