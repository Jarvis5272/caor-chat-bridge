# R05 TrellisBMA DataToProcess simulation Provenance Review

## Conditions

trellisbma_datatoprocess_sim

## Codex 拟定来源

Codex 拟定答案：该 row 是 TReconLM / TrellisBMA 相关 DataToProcess 的本地 clean IDS conversion，项目记录和 source audit 指向 `scripts/build_external_dataset_batch35_trellisbma_datatoprocess_full.py`，本地 converted source 为 `data/converted_external/trellisbma_datatoprocess_sim/Clusters.txt` 与 `Centers.txt`。TReconLM 本地教程还引用了 `tracereconstruction2026/TReconLM_datasets`，但 DataToProcess 与公开数据仓库的内容连续性尚未完全闭合。因此这是 partial-source-confirmed local conversion，而不是已完全验证 public release continuity。

## 证据等级

- evidence_level: strong_multi_source_inference
- confidence: medium
- evidence_ids: E003, E004, E013, E020

## 是否公开 release / 本地派生

- 公开 release 连续性只在本地证据支持处陈述；缺少内容连续性处不自动 closure。
- 本地派生/投影/转换不等于官方 paper benchmark。

## 剩余最少人工确认

- DataToProcess 原始文件是否来自 TReconLM official dataset/repo？
- 是否允许科研使用？
