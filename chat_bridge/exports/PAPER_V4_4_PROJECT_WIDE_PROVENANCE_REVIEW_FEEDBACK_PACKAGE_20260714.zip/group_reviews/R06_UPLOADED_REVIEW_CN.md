# R06 uploaded_* conditions Provenance Review

## Conditions

uploaded_compact, uploaded_real_clusters, uploaded_real_clusters_compact

## Codex 拟定来源

Codex 能恢复到本地 uploaded artifact：`uploaded_real_clusters` 使用 `data/uploaded_real_clusters/reads` 与 `truth`，compact 两行使用 `data/uploaded_real_clusters_compact/reads` 与 `truth`，转换脚本为 `scripts/convert_uploaded_clusters.py`。项目记录把 uploaded variants 明确归为 source-gap/user-upload artifacts，likely duplicate/derived，不能作为独立 paper dataset。最可能答案是：三条 uploaded row 是同一 uploaded/real-clusters family 的原始和 compact 处理视图，但上传者/原始来源/科研授权仍需要用户确认。

## 证据等级

- evidence_level: verified_local_file + verified_project_record
- confidence: medium
- evidence_ids: E002, E003, E004, E009, E010, E014, E016

## 是否公开 release / 本地派生

- 公开 release 连续性只在本地证据支持处陈述；缺少内容连续性处不自动 closure。
- 本地派生/投影/转换不等于官方 paper benchmark。

## 剩余最少人工确认

- uploaded 数据最初由谁/从哪里提供？
- 是否允许科研使用？
- compact 与 real_clusters 是否确认为同一上传 family 的处理视图？
