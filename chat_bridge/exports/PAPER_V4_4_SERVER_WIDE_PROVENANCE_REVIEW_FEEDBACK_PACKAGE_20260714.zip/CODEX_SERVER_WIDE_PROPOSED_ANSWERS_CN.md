# Codex Server-Wide Proposed Answers

## 【R01 Clover】

最可能的完整来源链：
Clover software/paper repository and local ACOR `data/clover_clusters/{reads,truth}` artifact -> Codex BBS-template views `clover` and `clover_clusters`; both production manifests point to the same raw read/truth directories and have identical 5000 clusters / 1,000,000 reads / mean IDS 0.000999. Server evidence confirms a Clover project checkout and local Clover paper PDF, but the original JTree-era dataset handoff into `data/clover_clusters` is still not documentary-closed.

支持证据：
- local production/source manifests and READMEs for frozen BBS-template rows
- server project index hits for related project/data directories
- git remote/history where available
- public source verification table where available
- migration/chat-export project records treated as exported project records, not private memory

仍有矛盾：
请确认 `data/clover_clusters` 最初是否来自 JTree/Clover 项目遗留数据并允许科研使用；确认不重新分发原始数据，或提供可分发许可。

Codex建议的正式答案：
local Clover artifact; source/project context verified; original dataset handoff requires author confirmation

证据等级：strong_multi_source_reconstruction

置信度：medium-high

用户只需选择：批准 / 修正 / 不批准。

## 【R02 NBT17 variants】

最可能的完整来源链：
Public/local `uwmisl/data-nbt17` clone (`id20.fastq.gz`, `id20.refs.txt.gz`, one 2018 commit) -> local `prepare_nbt17_random_access.py`/converted packs -> top500/top5000/top500_k15 BBS-template rows. The public repository title and local remote identify the source as the Random Access in Large-Scale DNA Data Storage data. Variant names are local subset/projection cells, not independent public datasets.

支持证据：
- local production/source manifests and READMEs for frozen BBS-template rows
- server project index hits for related project/data directories
- git remote/history where available
- public source verification table where available
- migration/chat-export project records treated as exported project records, not private memory

仍有矛盾：
未发现阻止 submission 的来源矛盾；仅 artifact redistribution 需要按投稿策略另行确认。

Codex建议的正式答案：
public base data plus local derivation verified

证据等级：verified_public_source + verified_local_file + verified_project_record

置信度：high

用户只需选择：批准 / 修正 / 不批准。

## 【R03 NComms19 Space Shuttle variants】

最可能的完整来源链：
Public/local `uwmisl/data-ncomms19-nanopore` clone -> local readme maps `space_shuttle` to `seqs_space_shuttle.txt` and `nanopore_run13.fastq.gz` -> `prepare_ncomms19_nanopore.py`/converted packs -> k15_min5, min5, min5_windowed rows. The three variants share the Space Shuttle source family; differences are local k/min/read filtering or windowed projection.

支持证据：
- local production/source manifests and READMEs for frozen BBS-template rows
- server project index hits for related project/data directories
- git remote/history where available
- public source verification table where available
- migration/chat-export project records treated as exported project records, not private memory

仍有矛盾：
未发现阻止 submission 的来源矛盾；仅 artifact redistribution 需要按投稿策略另行确认。

Codex建议的正式答案：
public base data plus local derivation verified

证据等级：verified_public_source + verified_local_file + verified_project_record

置信度：high

用户只需选择：批准 / 修正 / 不批准。

## 【R04 NComms19 Vitruvian variant】

最可能的完整来源链：
Public/local `uwmisl/data-ncomms19-nanopore` clone -> local readme maps `vitruvian` to `seqs_Vitruvian.txt` and `nanopore_run20.fastq.gz` -> `prepare_ncomms19_nanopore.py`/converted pack -> `ncomms19_vitruvian_min5_windowed`. It shares the NComms19 repository with Space Shuttle, but has separate reference/read source files.

支持证据：
- local production/source manifests and READMEs for frozen BBS-template rows
- server project index hits for related project/data directories
- git remote/history where available
- public source verification table where available
- migration/chat-export project records treated as exported project records, not private memory

仍有矛盾：
未发现阻止 submission 的来源矛盾；仅 artifact redistribution 需要按投稿策略另行确认。

Codex建议的正式答案：
public base data plus local derivation verified

证据等级：verified_public_source + verified_local_file + verified_project_record

置信度：high

用户只需选择：批准 / 修正 / 不批准。

## 【R05 TrellisBMA DataToProcess simulation】

最可能的完整来源链：
Local `TestBBS/tools/TrellisBMA` git clone with remote `microsoft/TrellisBMA` contains `DataToProcess/ClustersSim.txt` and `CentersSim.txt`; public GitHub page lists the `DataToProcess` directory and describes Trellis BMA as coded trace reconstruction on IDS channels. ACOR conversion script builds `data/converted_external/trellisbma_datatoprocess_sim/{Clusters.txt,Centers.txt}` from this family. This closes it as an official TrellisBMA local conversion, not merely a name match.

支持证据：
- local production/source manifests and READMEs for frozen BBS-template rows
- server project index hits for related project/data directories
- git remote/history where available
- public source verification table where available
- migration/chat-export project records treated as exported project records, not private memory

仍有矛盾：
未发现阻止 submission 的来源矛盾；仅 artifact redistribution 需要按投稿策略另行确认。

Codex建议的正式答案：
official TrellisBMA DataToProcess local conversion verified

证据等级：verified_public_source + verified_local_file + derived_by_verified_script

置信度：high

用户只需选择：批准 / 修正 / 不批准。

## 【R06 uploaded_* conditions】

最可能的完整来源链：
Local ACOR artifacts `data/uploaded_real_clusters/{reads,truth}` and `data/uploaded_real_clusters_compact/{reads,truth}` -> `scripts/convert_uploaded_clusters.py` -> three BBS-template rows. Production manifests show `uploaded_compact` and `uploaded_real_clusters_compact` use the same compact parent, while `uploaded_real_clusters` uses the non-compact parent. Migration/project records connect them to early BBS/17-condition experiments, but server review did not find an upstream archive/provider for the original uploaded bundle.

支持证据：
- local production/source manifests and READMEs for frozen BBS-template rows
- server project index hits for related project/data directories
- git remote/history where available
- public source verification table where available
- migration/chat-export project records treated as exported project records, not private memory

仍有矛盾：
请确认 uploaded 数据最初来源/提供者或 early BBS bundle；确认科研使用授权；确认 compact 是否为同一 uploaded family 的处理视图。

Codex建议的正式答案：
local uploaded artifact verified; upstream/provider still requires author confirmation

证据等级：verified_local_file + verified_project_record

置信度：medium

用户只需选择：批准 / 修正 / 不批准。
