# User Approval Checklist

对每组选择：批准 / 基本正确但修正 / 不批准 / 无法判断。

- R01 Clover: local Clover artifact; source/project context verified; original dataset handoff requires author confirmation
- R02 NBT17 variants: public base data plus local derivation verified
- R03 NComms19 Space Shuttle variants: public base data plus local derivation verified
- R04 NComms19 Vitruvian variant: public base data plus local derivation verified
- R05 TrellisBMA DataToProcess simulation: official TrellisBMA DataToProcess local conversion verified
- R06 uploaded_* conditions: local uploaded artifact verified; upstream/provider still requires author confirmation
