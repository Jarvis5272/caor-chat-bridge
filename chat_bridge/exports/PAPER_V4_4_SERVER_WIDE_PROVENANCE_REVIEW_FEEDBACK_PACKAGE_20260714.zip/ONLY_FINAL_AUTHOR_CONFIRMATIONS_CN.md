# Only Final Author Confirmations

1. R01 Clover: 请确认 `data/clover_clusters` 是否来自 JTree/Clover 项目遗留数据并允许科研使用；是否不重新分发原始数据。
2. R06 uploaded_*: 请确认 uploaded 数据最初来源/提供者或 early BBS bundle；是否允许科研使用；compact 是否为同一 uploaded family 的处理视图。
