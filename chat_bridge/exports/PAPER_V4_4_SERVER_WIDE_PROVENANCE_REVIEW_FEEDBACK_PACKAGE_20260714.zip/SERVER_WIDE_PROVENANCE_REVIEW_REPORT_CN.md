# Server-Wide Provenance Review Report

本轮为只读 provenance reconstruction；未运行实验，未修改算法、默认参数、锁定结果或 V4.3。

- scanned roots: /home/hanlinxuan/research, /home/hanlinxuan/Clover, /data, /mnt, /srv
- indexed name-hit files/dirs: 600
- git repositories scanned: 8
- imported chat exports: 0
- documentary-closable CR: 8
- author-confirmation CR: 5
- fully evidence-empty CR: 0
