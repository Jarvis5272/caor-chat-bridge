# R06 uploaded_* conditions Server Reconstruction

最可能完整来源链：

Local ACOR artifacts `data/uploaded_real_clusters/{reads,truth}` and `data/uploaded_real_clusters_compact/{reads,truth}` -> `scripts/convert_uploaded_clusters.py` -> three BBS-template rows. Production manifests show `uploaded_compact` and `uploaded_real_clusters_compact` use the same compact parent, while `uploaded_real_clusters` uses the non-compact parent. Migration/project records connect them to early BBS/17-condition experiments, but server review did not find an upstream archive/provider for the original uploaded bundle.

证据等级：verified_local_file + verified_project_record

置信度：medium

Codex 建议状态：local uploaded artifact verified; upstream/provider still requires author confirmation

剩余确认：请确认 uploaded 数据最初来源/提供者或 early BBS bundle；确认科研使用授权；确认 compact 是否为同一 uploaded family 的处理视图。

注意：作者线索只作为 `author_recollection_lead`，没有被单独升级为 verified fact。
