# R05 TrellisBMA DataToProcess simulation Server Reconstruction

最可能完整来源链：

Local `TestBBS/tools/TrellisBMA` git clone with remote `microsoft/TrellisBMA` contains `DataToProcess/ClustersSim.txt` and `CentersSim.txt`; public GitHub page lists the `DataToProcess` directory and describes Trellis BMA as coded trace reconstruction on IDS channels. ACOR conversion script builds `data/converted_external/trellisbma_datatoprocess_sim/{Clusters.txt,Centers.txt}` from this family. This closes it as an official TrellisBMA local conversion, not merely a name match.

证据等级：verified_public_source + verified_local_file + derived_by_verified_script

置信度：high

Codex 建议状态：official TrellisBMA DataToProcess local conversion verified

剩余确认：无必须问题；若要重新分发 Microsoft repo data files，请确认许可证/redistribution boundary。

注意：作者线索只作为 `author_recollection_lead`，没有被单独升级为 verified fact。
