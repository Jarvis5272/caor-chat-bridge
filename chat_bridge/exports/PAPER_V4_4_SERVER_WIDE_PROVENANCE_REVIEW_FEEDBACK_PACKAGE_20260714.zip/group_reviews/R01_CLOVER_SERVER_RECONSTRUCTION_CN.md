# R01 Clover Server Reconstruction

最可能完整来源链：

Clover software/paper repository and local ACOR `data/clover_clusters/{reads,truth}` artifact -> Codex BBS-template views `clover` and `clover_clusters`; both production manifests point to the same raw read/truth directories and have identical 5000 clusters / 1,000,000 reads / mean IDS 0.000999. Server evidence confirms a Clover project checkout and local Clover paper PDF, but the original JTree-era dataset handoff into `data/clover_clusters` is still not documentary-closed.

证据等级：strong_multi_source_reconstruction

置信度：medium-high

Codex 建议状态：local Clover artifact; source/project context verified; original dataset handoff requires author confirmation

剩余确认：请确认 `data/clover_clusters` 最初是否来自 JTree/Clover 项目遗留数据并允许科研使用；确认不重新分发原始数据，或提供可分发许可。

注意：作者线索只作为 `author_recollection_lead`，没有被单独升级为 verified fact。
