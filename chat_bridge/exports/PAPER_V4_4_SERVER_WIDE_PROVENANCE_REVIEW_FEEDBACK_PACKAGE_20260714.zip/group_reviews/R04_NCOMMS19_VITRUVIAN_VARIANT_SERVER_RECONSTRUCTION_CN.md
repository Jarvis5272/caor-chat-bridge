# R04 NComms19 Vitruvian variant Server Reconstruction

最可能完整来源链：

Public/local `uwmisl/data-ncomms19-nanopore` clone -> local readme maps `vitruvian` to `seqs_Vitruvian.txt` and `nanopore_run20.fastq.gz` -> `prepare_ncomms19_nanopore.py`/converted pack -> `ncomms19_vitruvian_min5_windowed`. It shares the NComms19 repository with Space Shuttle, but has separate reference/read source files.

证据等级：verified_public_source + verified_local_file + verified_project_record

置信度：high

Codex 建议状态：public base data plus local derivation verified

剩余确认：无必须问题；若投稿包包含原始 FASTQ/processed data，请另行确认再分发许可。

注意：作者线索只作为 `author_recollection_lead`，没有被单独升级为 verified fact。
