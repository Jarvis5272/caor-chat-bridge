# R03 NComms19 Space Shuttle variants Server Reconstruction

最可能完整来源链：

Public/local `uwmisl/data-ncomms19-nanopore` clone -> local readme maps `space_shuttle` to `seqs_space_shuttle.txt` and `nanopore_run13.fastq.gz` -> `prepare_ncomms19_nanopore.py`/converted packs -> k15_min5, min5, min5_windowed rows. The three variants share the Space Shuttle source family; differences are local k/min/read filtering or windowed projection.

证据等级：verified_public_source + verified_local_file + verified_project_record

置信度：high

Codex 建议状态：public base data plus local derivation verified

剩余确认：无必须问题；若投稿包包含原始 FASTQ/processed data，请另行确认再分发许可。

注意：作者线索只作为 `author_recollection_lead`，没有被单独升级为 verified fact。
