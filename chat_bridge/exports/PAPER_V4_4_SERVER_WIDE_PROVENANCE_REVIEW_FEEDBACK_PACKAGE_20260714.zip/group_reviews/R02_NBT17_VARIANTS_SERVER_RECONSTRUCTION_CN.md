# R02 NBT17 variants Server Reconstruction

最可能完整来源链：

Public/local `uwmisl/data-nbt17` clone (`id20.fastq.gz`, `id20.refs.txt.gz`, one 2018 commit) -> local `prepare_nbt17_random_access.py`/converted packs -> top500/top5000/top500_k15 BBS-template rows. The public repository title and local remote identify the source as the Random Access in Large-Scale DNA Data Storage data. Variant names are local subset/projection cells, not independent public datasets.

证据等级：verified_public_source + verified_local_file + verified_project_record

置信度：high

Codex 建议状态：public base data plus local derivation verified

剩余确认：无必须问题；若投稿包包含原始数据，请另行确认再分发许可。

注意：作者线索只作为 `author_recollection_lead`，没有被单独升级为 verified fact。
