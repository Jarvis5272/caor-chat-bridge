# PUBLIC_FULL_BENCHMARK_F5

Datasets: oligo0_full, ncomms19_365_dishes_full_strict_clean, binned_nanopore, microsoft_cnr_full, nbt17_id20_all_available

Known mapped scope subtotal: clusters=28488, reads=767282, prefix_rows=152469, prefix_read_uses=842961.

Mapping-blocked optional sources: none.

Baseline methods: Current Method, BBS, VS, BMALA minimum. CPL/MUSCLE not recommended for main table unless separately approved.

Scientific strength: highest provenance full-source core.
Deadline risk: lowest.
