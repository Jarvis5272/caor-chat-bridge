# PUBLIC_FULL_BENCHMARK_F7

Datasets: oligo0_full, ncomms19_365_dishes_full_strict_clean, binned_nanopore, microsoft_cnr_full, nbt17_id20_all_available, ncomms19_space_shuttle_full, trellisbma_datatoprocess_sim

Known mapped scope subtotal: clusters=35861, reads=848385, prefix_rows=189334, prefix_read_uses=997794.

Mapping-blocked optional sources: ncomms19_space_shuttle_full.

Baseline methods: Current Method, BBS, VS, BMALA minimum. CPL/MUSCLE not recommended for main table unless separately approved.

Scientific strength: stronger scale if mapping is solved.
Deadline risk: medium/high due mapping.
