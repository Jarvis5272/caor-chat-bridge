# PUBLIC_FULL_BENCHMARK_F6

Datasets: oligo0_full, ncomms19_365_dishes_full_strict_clean, binned_nanopore, microsoft_cnr_full, nbt17_id20_all_available, ncomms19_space_shuttle_full

Known mapped scope subtotal: clusters=28488, reads=767282, prefix_rows=152469, prefix_read_uses=842961.

Mapping-blocked optional sources: ncomms19_space_shuttle_full.

Baseline methods: Current Method, BBS, VS, BMALA minimum. CPL/MUSCLE not recommended for main table unless separately approved.

Scientific strength: stronger scale if mapping is solved.
Deadline risk: medium/high due mapping.
