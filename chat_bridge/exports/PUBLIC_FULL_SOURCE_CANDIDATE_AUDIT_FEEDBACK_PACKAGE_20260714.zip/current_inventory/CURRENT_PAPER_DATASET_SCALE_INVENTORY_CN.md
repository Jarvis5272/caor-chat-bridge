# Current Paper Dataset Scale Inventory

Existing locked full sources total: clusters=13,504; reads=448,090; prefix rows=75,830; prefix-read uses=454,951.

Historical CAPPED_17 remains historical_audited_benchmark. After provisional exclusions, the retained matched pool is 12 conditions / 11,000 dataset-cluster pairs / 54,172 prefix rows.

Previous PUBLIC_FULL_REPLACEMENT_CANDIDATES.tsv stale Oligo0 value of 10,000 clusters is retired; authoritative Oligo0 full is 1,466 clusters.
