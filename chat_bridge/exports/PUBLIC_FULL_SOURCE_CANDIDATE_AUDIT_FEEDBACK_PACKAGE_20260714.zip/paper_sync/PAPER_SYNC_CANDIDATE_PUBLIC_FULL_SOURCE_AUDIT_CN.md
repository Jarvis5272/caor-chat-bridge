# Paper Sync Candidate: Public Full-Source Candidate Audit

状态：PUBLIC_FULL_SOURCE_CORE_F5_READY_OPTIONAL_SOURCES_PENDING

F5 core has Microsoft CNR and NBT17 mapped candidates plus existing locked full sources. NComms Space/Vitruvian/Apollo raw full sources are public but full clean assignment is blocked by existing failed full packs. TrellisBMA is mapped but simulated.
