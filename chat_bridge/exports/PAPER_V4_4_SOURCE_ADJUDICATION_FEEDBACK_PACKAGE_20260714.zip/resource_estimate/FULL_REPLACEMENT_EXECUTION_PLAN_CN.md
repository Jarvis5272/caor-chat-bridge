# Full Replacement Execution Plan

- fastest defensible option: exclude uploaded_* and use already locked public full-source evidence plus minimal replacement design, but still requires new benchmark naming and baseline reruns before paper main table.
- strongest scientific option: Option B public full-source main benchmark; strongest provenance, highest compute cost.
- deadline-safe option: keep current V4.3 as historical/provenance-limited evidence, remove uploaded_* from submission claims, and avoid claiming CAPPED_17 as final public benchmark until rerun is approved.
本任务不启动替代实验。
