# Option A: Minimal Replacement

替换 uploaded_* 三个不可闭合 conditions；Clover 若保留，必须保守标注为 author-confirmed local JTree/Clover artifact。新 benchmark 不再使用 CAPPED_17 名称。若采用本方案，Current Method、BBS、VS、BMALA 至少需在新 row keys 上重跑；CPL/MUSCLE 根据 runtime/价值另行审批。
