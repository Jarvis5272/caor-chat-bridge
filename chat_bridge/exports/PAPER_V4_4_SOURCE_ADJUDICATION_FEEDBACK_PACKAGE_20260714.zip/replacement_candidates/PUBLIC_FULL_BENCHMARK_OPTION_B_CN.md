# Option B: Public Full-Source Main Benchmark

重新定义 submission main benchmark，只使用公开来源和本地内容连续性清楚的 full sources，例如 NBT17 id20 full、NComms19 Space Shuttle/Vitruvian/365 Dishes、Binned Nanopore、Oligo0、TrellisBMA DataToProcess。不追求 17 conditions，优先保证来源独立性、full scope、prefix-online 可复现。所有主方法至少 Current/BBS/VS/BMALA 重跑。
